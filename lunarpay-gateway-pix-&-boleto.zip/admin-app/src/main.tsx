import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from 'sonner'
import App from './App'
import { AuthProvider } from './hooks/useAuth'
import './index.css'

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } },
})

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter basename="/admin/app">
        <AuthProvider>
          <App />
        </AuthProvider>
      </BrowserRouter>
      <Toaster theme="dark" position="top-right" toastOptions={{ className: '!bg-[#141416] !border !border-white/10 !text-white' }} />
    </QueryClientProvider>
  </StrictMode>,
)
