import { Badge } from './badge'

const MAP: Record<string, { label: string; status: 'success' | 'warning' | 'danger' | 'neutral' }> = {
  paid: { label: 'Pago', status: 'success' },
  pending: { label: 'Pendente', status: 'warning' },
  refunded: { label: 'Reembolsado', status: 'neutral' },
  failed: { label: 'Falhou', status: 'danger' },
}

export function StatusBadge({ status }: { status: string }) {
  const m = MAP[status] ?? { label: status, status: 'neutral' as const }
  return <Badge status={m.status}>{m.label}</Badge>
}
