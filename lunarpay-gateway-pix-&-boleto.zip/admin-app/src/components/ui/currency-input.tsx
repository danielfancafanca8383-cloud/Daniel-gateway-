import * as React from 'react'
import { cn } from '@/lib/utils'

/**
 * Input de valor em reais que nunca produz NaN pro backend: guarda os
 * centavos como inteiro internamente e só formata pra exibição, então
 * não importa o que o usuário digite ou cole ("R$ 10,00", "10.00" etc.)
 * — o valor numérico enviado é sempre o que o dígito realmente formou.
 */
export function CurrencyInput({
  valueCents,
  onValueChange,
  className,
  id,
  required,
}: {
  valueCents: number
  onValueChange: (cents: number) => void
  className?: string
  id?: string
  required?: boolean
}) {
  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const digits = e.target.value.replace(/\D/g, '')
    onValueChange(digits === '' ? 0 : parseInt(digits, 10))
  }

  const display = (valueCents / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

  return (
    <div className="relative">
      <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm text-muted">R$</span>
      <input
        id={id}
        inputMode="numeric"
        placeholder="0,00"
        value={valueCents === 0 ? '' : display}
        onChange={handleChange}
        required={required}
        className={cn(
          'h-11 w-full rounded-md border border-border-subtle bg-surface-1 pl-9 pr-3.5 text-sm text-foreground placeholder:text-muted-foreground',
          'transition-[border-color,box-shadow] duration-[var(--motion-fast)]',
          'focus:border-border-active focus:outline-none focus:ring-2 focus:ring-white/10',
          className,
        )}
      />
    </div>
  )
}
