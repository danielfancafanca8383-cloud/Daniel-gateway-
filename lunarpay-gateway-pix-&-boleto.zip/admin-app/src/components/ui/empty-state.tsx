import type { LucideIcon } from 'lucide-react'
import { Button } from './button'

export function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
}: {
  icon: LucideIcon
  title: string
  description: string
  actionLabel?: string
  onAction?: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border-subtle py-16 text-center">
      <Icon className="h-9 w-9 text-muted-foreground" strokeWidth={1.5} />
      <div className="max-w-xs">
        <p className="font-semibold text-foreground">{title}</p>
        <p className="mt-1 text-sm text-muted">{description}</p>
      </div>
      {actionLabel && (
        <Button size="sm" className="mt-2 w-auto" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  )
}
