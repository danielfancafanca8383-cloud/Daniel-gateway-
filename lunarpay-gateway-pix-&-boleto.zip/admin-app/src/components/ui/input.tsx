import * as React from 'react'
import { cn } from '@/lib/utils'

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        'h-11 w-full rounded-md border border-border-subtle bg-surface-1 px-3.5 text-sm text-foreground placeholder:text-muted-foreground',
        'transition-[border-color,box-shadow] duration-[var(--motion-fast)]',
        'focus:border-border-active focus:outline-none focus:ring-2 focus:ring-white/10',
        'aria-invalid:border-danger/60',
        className,
      )}
      {...props}
    />
  ),
)
Input.displayName = 'Input'

export function Label({ className, ...props }: React.LabelHTMLAttributes<HTMLLabelElement>) {
  return <label className={cn('mb-1.5 block text-sm font-medium text-muted', className)} {...props} />
}

export function FieldError({ children }: { children?: React.ReactNode }) {
  if (!children) return null
  return <p className="mt-1.5 text-xs text-danger">{children}</p>
}
