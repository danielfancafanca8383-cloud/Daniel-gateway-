import * as React from 'react'
import { cn } from '@/lib/utils'

export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'rounded-xl border border-border-subtle bg-surface-1 p-5 backdrop-blur-xl',
        className,
      )}
      {...props}
    />
  )
}

export function CardInteractive({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'rounded-xl border border-border-subtle bg-surface-1 p-5 backdrop-blur-xl cursor-pointer',
        'transition-[transform,border-color,background] duration-[var(--motion-fast)] ease-[var(--ease-out)]',
        'hover:-translate-y-0.5 hover:border-border-hover hover:bg-surface-2',
        className,
      )}
      {...props}
    />
  )
}

export function CardHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('mb-3 flex items-center justify-between', className)} {...props} />
}

export function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h3 className={cn('text-sm font-medium text-muted', className)} {...props} />
}
