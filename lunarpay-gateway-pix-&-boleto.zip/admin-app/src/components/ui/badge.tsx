import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'

const badgeVariants = cva(
  'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold',
  {
    variants: {
      status: {
        success: 'bg-success/12 text-success',
        warning: 'bg-warning/12 text-warning',
        danger: 'bg-danger/12 text-danger',
        neutral: 'bg-surface-2 text-muted',
      },
    },
    defaultVariants: { status: 'neutral' },
  },
)

export function Badge({
  className,
  status,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>) {
  return (
    <span className={cn(badgeVariants({ status }), className)}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      <span {...props} />
    </span>
  )
}
