import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-semibold ' +
    'transition-[transform,box-shadow,background,border-color,filter] duration-[var(--motion-fast)] ease-[var(--ease-out)] ' +
    'disabled:pointer-events-none disabled:opacity-50 select-none ' +
    'active:scale-[0.98] active:translate-y-px',
  {
    variants: {
      variant: {
        primary:
          'bg-primary text-primary-foreground shadow-[0_8px_26px_rgba(255,255,255,0.10),inset_0_1px_0_rgba(255,255,255,0.35)] ' +
          'hover:bg-primary-hover hover:-translate-y-px hover:shadow-[0_10px_32px_rgba(255,255,255,0.14)]',
        secondary:
          'bg-surface-2 text-foreground border border-border-subtle hover:bg-surface-3 hover:border-border-hover hover:-translate-y-px',
        soft: 'bg-surface-1 text-foreground hover:bg-surface-2',
        ghost: 'bg-transparent text-muted hover:text-foreground hover:bg-surface-1',
        outline: 'bg-transparent border border-border-subtle text-foreground hover:border-border-hover hover:bg-surface-1',
        destructive: 'bg-danger/12 text-danger border border-danger/30 hover:bg-danger/18',
        icon: 'bg-surface-1 text-foreground hover:bg-surface-2 rounded-full',
      },
      size: {
        sm: 'h-9 px-3 text-sm',
        md: 'h-11 px-4 text-sm',
        lg: 'h-12 px-6 text-base',
        checkout: 'h-14 px-6 text-base w-full',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: { variant: 'primary', size: 'md' },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, disabled, children, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(buttonVariants({ variant, size }), className)}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  ),
)
Button.displayName = 'Button'
