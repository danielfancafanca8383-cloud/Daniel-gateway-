import { NavLink } from 'react-router-dom'
import {
  LayoutGrid,
  QrCode,
  Receipt,
  ArrowLeftRight,
  Box,
  Ticket,
  Settings,
  UserCog,
  Landmark,
  Percent,
  KeyRound,
  LayoutDashboard,
  Users,
  CheckCircle2,
  Activity,
  LogOut,
} from 'lucide-react'
import { useAuth, useLogout } from '@/hooks/useAuth'
import { cn } from '@/lib/utils'

interface NavItemDef {
  to: string
  label: string
  icon: any
  end?: boolean
  badge?: string
  badgeType?: 'green' | 'count'
}

const mainItems: NavItemDef[] = [
  { to: '/', label: 'Início', icon: LayoutGrid, end: true },
  { to: '/gerar-pix', label: 'Gerar Pix', icon: QrCode, badge: 'Novo', badgeType: 'green' },
  { to: '/boleto', label: 'Gerar boleto', icon: Receipt, badge: 'Novo', badgeType: 'green' },
  { to: '/vendas', label: 'Extrato & Vendas', icon: ArrowLeftRight },
]

const manageItems: NavItemDef[] = [
  { to: '/produtos', label: 'Produtos', icon: Box },
  { to: '/cupons', label: 'Cupons', icon: Ticket },
  { to: '/settings', label: 'Configurações', icon: Settings },
  { to: '/conta', label: 'Usuário & Senha', icon: UserCog },
]

const financeItems: NavItemDef[] = [
  { to: '/saque', label: 'Saque', icon: Landmark },
  { to: '/taxas', label: 'Taxas & Rotas', icon: Percent },
  { to: '/api', label: 'API', icon: KeyRound },
]

const ownerItems: NavItemDef[] = [
  { to: '/dashboard-geral', label: 'Dashboard geral', icon: LayoutDashboard },
  { to: '/usuarios', label: 'Usuários', icon: Users },
  { to: '/saques-admin', label: 'Aprovar saques', icon: CheckCircle2 },
  { to: '/auditoria', label: 'Auditoria', icon: Activity },
]

function Item({ to, label, icon: Icon, end, badge, badgeType }: NavItemDef) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          'group flex items-center justify-between rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all cursor-pointer',
          isActive
            ? 'bg-gradient-to-br from-[#7c3aed] to-[#2563eb] text-white shadow-[0_4px_16px_rgba(124,58,237,0.35)]'
            : 'text-[#94a3b8] hover:bg-white/[0.04] hover:text-white',
        )
      }
    >
      <span className="flex items-center gap-3">
        <Icon className="h-[18px] w-[18px]" strokeWidth={2} />
        <span>{label}</span>
      </span>
      {badge && badgeType === 'green' && (
        <span className="rounded-full bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-400">
          {badge}
        </span>
      )}
      {badge && badgeType === 'count' && (
        <span className="rounded-full bg-[#ef4444] px-1.5 py-0.5 text-[11px] font-bold text-white leading-none">
          {badge}
        </span>
      )}
    </NavLink>
  )
}

export function Sidebar({ open }: { open: boolean }) {
  const { me } = useAuth()
  const logout = useLogout()
  const initial = (me?.username?.[0] || 'D').toUpperCase()

  return (
    <aside
      className={cn(
        'fixed inset-y-0 left-0 z-40 flex w-[280px] flex-col border-r border-white/[0.05] bg-[#0d0e12] p-4 sm:p-5 transition-transform duration-200',
        open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
      )}
    >
      {/* Cabeçalho do Utilizador */}
      <NavLink
        to="/"
        className="flex items-center gap-3 pb-5 mb-3 border-b border-white/[0.05] px-1 hover:opacity-90 transition-opacity"
      >
        <div className="flex h-[42px] w-[42px] items-center justify-center rounded-full bg-white/[0.08] border border-white/[0.15] text-base font-bold text-white shadow-inner">
          {initial}
        </div>
        <div className="min-w-0 flex flex-col">
          <span className="truncate text-sm font-semibold text-white leading-tight">
            {me?.username || 'danielfancabenvindo'}
          </span>
          <span className="truncate text-xs text-[#8a8d9b] mt-0.5">
            {me?.site_name || 'Zukify'}
          </span>
        </div>
      </NavLink>

      {/* Navegação */}
      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto pr-1">
        <div className="flex flex-col gap-1">
          {mainItems.map((i) => <Item key={i.to} {...i} />)}
        </div>

        <div className="mb-2 mt-5 px-3 text-[11px] font-bold uppercase tracking-[0.8px] text-[#525866]">
          Gestão & Vender
        </div>
        <div className="flex flex-col gap-1">
          {manageItems.map((i) => <Item key={i.to} {...i} />)}
        </div>

        <div className="mb-2 mt-5 px-3 text-[11px] font-bold uppercase tracking-[0.8px] text-[#525866]">
          Financeiro & Dev
        </div>
        <div className="flex flex-col gap-1">
          {financeItems.map((i) => <Item key={i.to} {...i} />)}
        </div>

        {me?.is_owner && (
          <>
            <div className="mb-2 mt-5 px-3 text-[11px] font-bold uppercase tracking-[0.8px] text-[#525866]">
              Sistema
            </div>
            <div className="flex flex-col gap-1">
              {ownerItems.map((i) => <Item key={i.to} {...i} />)}
            </div>
          </>
        )}
      </nav>

      {/* Sair da Conta */}
      <div className="pt-4 mt-auto border-t border-white/[0.05]">
        <button
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-[#ef4444] transition-all hover:bg-[#ef4444]/10 hover:text-[#f87171] cursor-pointer"
        >
          <LogOut className="h-[18px] w-[18px]" strokeWidth={2} />
          <span>Sair da Conta</span>
        </button>
      </div>
    </aside>
  )
}
