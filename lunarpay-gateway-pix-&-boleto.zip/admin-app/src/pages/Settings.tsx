import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Check, ShieldCheck, Send, Layers } from 'lucide-react'
import { Card, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

interface SettingsData {
  site_name: string
  has_api_key: boolean
  has_telegram_bot: boolean
  has_telegram_chat: boolean
  nominal: string
}

export default function Settings() {
  const { me, refetch: refetchMe } = useAuth()
  const qc = useQueryClient()
  const [error, setError] = React.useState('')
  const [savedSuccess, setSavedSuccess] = React.useState(false)

  const { data } = useQuery({
    queryKey: ['settings'],
    queryFn: () => api.get<SettingsData>('/api/settings.php'),
    retry: 1,
  })

  const mutation = useMutation({
    mutationFn: (form: Record<string, unknown>) => api.postCsrf('/api/settings.php', form, me?.csrf || ''),
    onSuccess: (res: any) => {
      toast.success('Configurações salvas com sucesso!')
      setError('')
      setSavedSuccess(true)
      setTimeout(() => setSavedSuccess(false), 3000)
      qc.invalidateQueries({ queryKey: ['settings'] })
      refetchMe()
    },
    onError: (e) => {
      setError(e instanceof ApiError ? e.message : 'Falha ao salvar configurações.')
    },
  })

  // Dados com fallback para me caso o endpoint demore a responder
  const siteName = data?.site_name ?? me?.site_name ?? 'Zukify'
  const hasApiKey = data?.has_api_key ?? me?.has_api_key ?? false
  const nominal = data?.nominal ?? me?.nominal ?? 'nominal1'
  const hasTelegramBot = data?.has_telegram_bot ?? false
  const hasTelegramChat = data?.has_telegram_chat ?? false

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError('')
    const form = new FormData(e.currentTarget)
    mutation.mutate({
      site_name: form.get('site_name'),
      lunarpay_api_key: form.get('lunarpay_api_key'),
      nominal: form.get('nominal'),
      telegram_bot_token: form.get('telegram_bot_token'),
      telegram_chat_id: form.get('telegram_chat_id'),
      clear_telegram: form.get('clear_telegram') === 'on',
    })
  }

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto pb-16">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold tracking-tight text-white">Configurações do gateway</h1>
        <p className="text-sm text-[#94a3b8]">Identidade, processamento e notificações da sua plataforma.</p>
      </div>

      {savedSuccess && (
        <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3.5 text-sm text-emerald-300 flex items-center gap-2">
          <Check className="h-4 w-4" /> Configurações salvas e aplicadas em toda a plataforma!
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          
          {/* Card 1: Identidade */}
          <Card className="flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2 text-rose-500">
                <Layers className="h-4 w-4" />
                <CardTitle className="text-rose-500">IDENTIDADE</CardTitle>
              </div>
              <h2 className="mb-4 text-base font-semibold text-white">Marca do checkout</h2>
              
              <div className="space-y-3">
                <div>
                  <Label htmlFor="site_name">Nome público da plataforma</Label>
                  <Input 
                    id="site_name" 
                    name="site_name" 
                    maxLength={80} 
                    defaultValue={siteName} 
                    key={siteName}
                    required 
                    placeholder="ex: Zukify"
                  />
                  <p className="mt-2 text-xs text-[#64748b]">
                    Aparece no topo do checkout Pix, links de pagamento e comprovantes.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Card 2: LunarPay Processamento */}
          <Card className="flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2 text-blue-500">
                <ShieldCheck className="h-4 w-4" />
                <CardTitle className="text-blue-500">LUNARPAY</CardTitle>
              </div>
              <h2 className="mb-4 text-base font-semibold text-white">Chaves & Rota Pix</h2>
              
              <div className="space-y-3">
                <div>
                  <Label htmlFor="lunarpay_api_key">Ghost Key (API Key)</Label>
                  <Input
                    id="lunarpay_api_key"
                    name="lunarpay_api_key"
                    type="password"
                    autoComplete="new-password"
                    placeholder={hasApiKey ? '•••••••••••• (chave ativa)' : 'ghost_...'}
                  />
                  <p className="mt-1 text-xs text-[#64748b]">
                    {hasApiKey ? 'Chave cadastrada. Deixe em branco para manter.' : 'Cole sua chave ghost_ da LunarPay.'}
                  </p>
                </div>

                <div>
                  <Label htmlFor="nominal">Rota de Liquidação</Label>
                  <select
                    id="nominal"
                    name="nominal"
                    defaultValue={nominal}
                    key={nominal}
                    className="h-11 w-full rounded-xl border border-white/10 bg-[#121319] px-3.5 text-sm text-white focus:border-[#7c3aed] focus:outline-none transition-all"
                  >
                    <option value="nominal1">Nominal 1 · Reembolso automático (Padrão)</option>
                    <option value="nominal3">Nominal 3 · Alta velocidade</option>
                    <option value="nominal7">Nominal 7 · Baixo custo</option>
                  </select>
                </div>
              </div>
            </div>
          </Card>

          {/* Card 3: Telegram Alertas */}
          <Card className="flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2 text-emerald-500">
                <Send className="h-4 w-4" />
                <CardTitle className="text-emerald-500">ALERTAS</CardTitle>
              </div>
              <h2 className="mb-4 text-base font-semibold text-white">Telegram Bot</h2>
              
              <div className="space-y-3">
                <div>
                  <Label htmlFor="telegram_bot_token">Token do bot</Label>
                  <Input
                    id="telegram_bot_token"
                    name="telegram_bot_token"
                    type="password"
                    autoComplete="new-password"
                    placeholder={hasTelegramBot ? '•••••••• (configurado)' : 'Token do @BotFather'}
                  />
                </div>

                <div>
                  <Label htmlFor="telegram_chat_id">Chat ID do Telegram</Label>
                  <Input 
                    id="telegram_chat_id" 
                    name="telegram_chat_id" 
                    placeholder={hasTelegramChat ? 'Configurado' : 'ID numérico (ex: 12345678)'} 
                  />
                </div>

                <label className="flex items-center gap-2 text-xs text-[#94a3b8] cursor-pointer pt-1">
                  <input type="checkbox" name="clear_telegram" className="h-4 w-4 rounded border-white/10 bg-[#121319]" />
                  <span>Remover integração do Telegram</span>
                </label>
              </div>
            </div>
          </Card>
        </div>

        {error && <FieldError>{error}</FieldError>}

        <div className="flex items-center justify-end gap-3 pt-2">
          <Button type="submit" loading={mutation.isPending} className="px-6 py-2.5">
            Salvar alterações
          </Button>
        </div>
      </form>
    </div>
  )
}
