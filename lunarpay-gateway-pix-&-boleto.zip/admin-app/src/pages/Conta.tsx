import * as React from 'react'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

export default function Conta() {
  const { me, refetch } = useAuth()
  const [error, setError] = React.useState('')
  const formRef = React.useRef<HTMLFormElement>(null)

  const mutation = useMutation({
    mutationFn: (body: Record<string, string>) => api.postCsrf('/api/conta.php', body, me!.csrf),
    onSuccess: () => {
      toast.success('Dados atualizados com sucesso.')
      setError('')
      formRef.current?.reset()
      refetch()
    },
    onError: (e) => setError(e instanceof ApiError ? e.message : 'Falha ao salvar.'),
  })

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    mutation.mutate({
      current_pass: String(form.get('current_pass') || ''),
      new_user: String(form.get('new_user') || ''),
      new_pass: String(form.get('new_pass') || ''),
      new_pass2: String(form.get('new_pass2') || ''),
    })
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Usuário & Senha</h1>
        <p className="text-sm text-muted">Altere seu nome de usuário e, se quiser, defina uma nova senha.</p>
      </div>

      <Card>
        <form ref={formRef} onSubmit={handleSubmit}>
          <Label htmlFor="current_pass">Senha atual (obrigatória pra confirmar qualquer mudança)</Label>
          <Input id="current_pass" name="current_pass" type="password" required autoFocus />

          <div className="mt-4">
            <Label htmlFor="new_user">Nome de usuário</Label>
            <Input id="new_user" name="new_user" defaultValue={me?.username} required />
          </div>

          <div className="mt-4">
            <Label htmlFor="new_pass">Nova senha (deixe em branco pra manter a atual)</Label>
            <Input id="new_pass" name="new_pass" type="password" minLength={12} />
          </div>

          <div className="mt-4">
            <Label htmlFor="new_pass2">Confirme a nova senha</Label>
            <Input id="new_pass2" name="new_pass2" type="password" minLength={12} />
          </div>

          <FieldError>{error}</FieldError>

          <Button type="submit" className="mt-5" loading={mutation.isPending}>Salvar</Button>
        </form>
      </Card>
    </div>
  )
}
