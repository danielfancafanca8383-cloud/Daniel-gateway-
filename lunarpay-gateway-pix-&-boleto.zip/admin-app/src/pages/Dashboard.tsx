import * as React from 'react'
import { useQuery } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import {
  Wallet,
  TrendingUp,
  ShoppingCart,
  ArrowDownRight,
  Link as LinkIcon,
  ShoppingBag,
  BarChart2,
  PiggyBank,
  Link2,
  Search,
  Sun,
  Bell,
  Check,
  QrCode,
  History,
  Menu as MenuIcon,
  LayoutGrid,
} from 'lucide-react'
import { api } from '@/lib/api'
import { formatBRL } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'

interface DashboardData {
  site_name: string
  saldo: number
  hoje_valor: number
  hoje_vendas: number
  volume_mes: number
  pendentes: number
  total_pedidos: number
  total_pagos: number
  pct_pago: number
  public_checkout_url: string
}

export default function Dashboard() {
  const { me } = useAuth()
  const navigate = useNavigate()
  const [copied, setCopied] = React.useState(false)

  const { data, isLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get<DashboardData>('/api/dashboard.php'),
  })

  const initial = (me?.username?.[0] || 'D').toUpperCase()
  const inviteUrl = data?.public_checkout_url || (typeof window !== 'undefined' ? `${window.location.origin}/index.php?u=${me?.username || 'admin'}` : 'https://lunarpay.site/r/demo')

  const copyLink = () => {
    navigator.clipboard.writeText(inviteUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const saldo = data?.saldo ?? 0
  const volumeMes = data?.volume_mes ?? 0
  const hojeValor = data?.hoje_valor ?? 0
  const hojeVendas = data?.hoje_vendas ?? 0
  const pendentes = data?.pendentes ?? 0

  return (
    <div className="mx-auto w-full max-w-[520px] pb-24 text-white">
      {/* Topo / Header */}
      <header className="flex items-center justify-between pb-5 pt-1">
        <div className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-[#1a1b23] text-base font-bold text-white shadow-inner">
          {initial}
        </div>
        <div className="flex items-center gap-3">
          <button className="flex h-9 w-9 items-center justify-center rounded-full border border-white/5 bg-[#16171f] text-[#a0a5b5] hover:text-white transition-colors cursor-pointer">
            <Search className="h-4 w-4" />
          </button>
          <button className="flex h-9 w-9 items-center justify-center rounded-full border border-white/5 bg-[#16171f] text-[#a0a5b5] hover:text-white transition-colors cursor-pointer">
            <Sun className="h-4 w-4" />
          </button>
          <button className="relative flex h-9 w-9 items-center justify-center rounded-full border border-white/5 bg-[#16171f] text-[#a0a5b5] hover:text-white transition-colors cursor-pointer">
            <Bell className="h-4 w-4" />
            <span className="absolute -right-0.5 -top-0.5 rounded-full border-2 border-[#0b0c10] bg-[#e11d48] px-1 py-px text-[9px] font-extrabold text-white leading-none">
              9+
            </span>
          </button>
        </div>
      </header>

      {!me?.has_api_key && (
        <div className="mb-4 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-300">
          Você ainda não cadastrou sua chave da LunarPay.{' '}
          <button onClick={() => navigate('/settings')} className="font-semibold underline cursor-pointer">
            Cadastrar agora
          </button>
        </div>
      )}

      {/* Grid de Métricas (2x2) */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Saldo Total */}
        <div className="rounded-2xl border border-white/5 bg-[#12131a] p-4 shadow-lg shadow-black/40">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-rose-500/15 text-[#f43f5e]">
              <Wallet className="h-4 w-4" />
            </div>
            <span className="text-xs font-medium text-[#9499a8]">Saldo Total</span>
          </div>
          <div className="text-xl font-bold tracking-tight text-white mb-0.5 tabular-nums">
            {isLoading ? '...' : formatBRL(saldo)}
          </div>
          <div className="text-[11px] text-[#64697a]">acumulado</div>
        </div>

        {/* Volume Mensal */}
        <div className="rounded-2xl border border-white/5 bg-[#12131a] p-4 shadow-lg shadow-black/40">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-500/15 text-[#3b82f6]">
              <TrendingUp className="h-4 w-4" />
            </div>
            <span className="text-xs font-medium text-[#9499a8]">Volume Mensal</span>
          </div>
          <div className="text-xl font-bold tracking-tight text-white mb-0.5 tabular-nums">
            {isLoading ? '...' : formatBRL(volumeMes)}
          </div>
          <div className="text-[11px] text-[#64697a]">este mês</div>
        </div>

        {/* Vendas Hoje */}
        <div className="rounded-2xl border border-white/5 bg-[#12131a] p-4 shadow-lg shadow-black/40">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-500/15 text-[#10b981]">
              <ShoppingCart className="h-4 w-4" />
            </div>
            <span className="text-xs font-medium text-[#9499a8]">Vendas Hoje</span>
          </div>
          <div className="text-xl font-bold tracking-tight text-white mb-0.5 tabular-nums">
            {isLoading ? '...' : formatBRL(hojeValor)}
          </div>
          <div className="text-[11px] text-[#64697a]">{hojeVendas} venda(s) realizadas</div>
        </div>

        {/* Pendentes */}
        <div className="rounded-2xl border border-white/5 bg-[#12131a] p-4 shadow-lg shadow-black/40">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-500/15 text-[#f59e0b]">
              <ArrowDownRight className="h-4 w-4" />
            </div>
            <span className="text-xs font-medium text-[#9499a8]">Pendentes</span>
          </div>
          <div className="text-xl font-bold tracking-tight text-white mb-0.5 tabular-nums">
            {isLoading ? '...' : pendentes}
          </div>
          <div className="text-[11px] text-[#64697a]">aguardando pagamento</div>
        </div>
      </div>

      {/* Acesso Rápido */}
      <div className="mb-4 rounded-[20px] border border-white/5 bg-[#12131a] p-5 shadow-lg shadow-black/40">
        <h2 className="text-[15px] font-bold text-white mb-4">Acesso rápido</h2>
        <div className="grid grid-cols-4 gap-3 text-center">
          <button
            onClick={() => navigate('/produtos')}
            className="flex flex-col items-center gap-2 group cursor-pointer"
          >
            <div className="flex h-[52px] w-[52px] items-center justify-center rounded-[18px] bg-rose-500/12 text-[#f43f5e] transition-transform active:scale-95 group-hover:scale-105">
              <LinkIcon className="h-5 w-5" />
            </div>
            <span className="text-[11px] font-medium text-[#9499a8]">Links</span>
          </button>

          <button
            onClick={() => navigate('/vendas')}
            className="flex flex-col items-center gap-2 group cursor-pointer"
          >
            <div className="flex h-[52px] w-[52px] items-center justify-center rounded-[18px] bg-emerald-500/12 text-[#10b981] transition-transform active:scale-95 group-hover:scale-105">
              <ShoppingBag className="h-5 w-5" />
            </div>
            <span className="text-[11px] font-medium text-[#9499a8]">Vendas</span>
          </button>

          <button
            onClick={() => navigate('/dashboard-geral')}
            className="flex flex-col items-center gap-2 group cursor-pointer"
          >
            <div className="flex h-[52px] w-[52px] items-center justify-center rounded-[18px] bg-blue-500/12 text-[#3b82f6] transition-transform active:scale-95 group-hover:scale-105">
              <BarChart2 className="h-5 w-5" />
            </div>
            <span className="text-[11px] font-medium text-[#9499a8]">Relatórios</span>
          </button>

          <button
            onClick={() => navigate('/saque')}
            className="flex flex-col items-center gap-2 group cursor-pointer"
          >
            <div className="flex h-[52px] w-[52px] items-center justify-center rounded-[18px] bg-amber-500/12 text-[#f59e0b] transition-transform active:scale-95 group-hover:scale-105">
              <PiggyBank className="h-5 w-5" />
            </div>
            <span className="text-[11px] font-medium text-[#9499a8]">Cofres</span>
          </button>
        </div>
      </div>

      {/* Guardado em Cofres */}
      <div className="mb-4 rounded-[20px] border border-white/5 bg-[#12131a] p-5 shadow-lg shadow-black/40">
        <div className="flex items-center gap-2.5 mb-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/15 text-[#10b981]">
            <PiggyBank className="h-5 w-5" />
          </div>
          <span className="text-[11px] font-bold tracking-wider text-[#64697a] uppercase">
            GUARDADO EM COFRES
          </span>
        </div>
        <div className="text-2xl font-extrabold text-[#10b981] mb-1.5 tabular-nums">
          {isLoading ? '...' : formatBRL(saldo * 0.4)}
        </div>
        <button
          onClick={() => navigate('/saque')}
          className="inline-flex items-center gap-1 text-xs font-semibold text-[#10b981] hover:underline cursor-pointer"
        >
          <span>Ver Cofres</span>
          <span>&gt;</span>
        </button>
      </div>

      {/* Convide Novos Parceiros */}
      <div className="mb-4 rounded-[20px] border border-white/5 bg-[#12131a] p-5 shadow-lg shadow-black/40">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-rose-500/15 text-[#f43f5e]">
            <Link2 className="h-4 w-4" />
          </div>
          <h2 className="text-[15px] font-bold text-white">Convide novos parceiros</h2>
        </div>
        <p className="text-xs text-[#808596] leading-relaxed mb-3.5">
          Indique novos parceiros usando seu código exclusivo e libere o acesso deles com taxas de 1,5%.
        </p>

        <div className="flex items-center rounded-xl border border-white/[0.08] bg-[#090a0d] p-1 pl-3.5">
          <input
            type="text"
            readOnly
            value={inviteUrl}
            className="w-full bg-transparent text-xs text-[#808596] outline-none truncate"
          />
          <button
            onClick={copyLink}
            className={`whitespace-nowrap rounded-lg px-3.5 py-2 text-xs font-semibold text-white transition-all cursor-pointer ${
              copied ? 'bg-emerald-600' : 'bg-[#e11d48] hover:bg-[#be123c]'
            }`}
          >
            {copied ? (
              <span className="flex items-center gap-1">
                <Check className="h-3.5 w-3.5" /> Copiado!
              </span>
            ) : (
              'Copiar Link'
            )}
          </button>
        </div>
      </div>

      {/* Navegação Flutuante Inferior (Bottom Nav) */}
      <nav className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[calc(100%-32px)] max-w-[440px] rounded-[30px] border border-white/[0.08] bg-[#12131a]/90 p-1.5 backdrop-blur-xl shadow-2xl shadow-black/80 flex items-center justify-between z-50">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-1.5 rounded-full bg-[#e11d48] px-3.5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-rose-600/40 cursor-pointer"
        >
          <LayoutGrid className="h-4 w-4" />
          <span>Início</span>
        </button>

        <button
          onClick={() => navigate('/gerar-pix')}
          className="flex h-10 w-10 items-center justify-center rounded-full text-[#717688] hover:text-white transition-colors cursor-pointer"
          title="Gerar Pix"
        >
          <QrCode className="h-5 w-5" />
        </button>

        <button
          onClick={() => navigate('/saque')}
          className="flex h-10 w-10 items-center justify-center rounded-full text-[#717688] hover:text-white transition-colors cursor-pointer"
          title="Cofres & Saque"
        >
          <PiggyBank className="h-5 w-5" />
        </button>

        <button
          onClick={() => navigate('/vendas')}
          className="flex h-10 w-10 items-center justify-center rounded-full text-[#717688] hover:text-white transition-colors cursor-pointer"
          title="Histórico de Vendas"
        >
          <History className="h-5 w-5" />
        </button>

        <button
          onClick={() => navigate('/settings')}
          className="flex h-10 w-10 items-center justify-center rounded-full text-[#717688] hover:text-white transition-colors cursor-pointer"
          title="Menu & Configurações"
        >
          <MenuIcon className="h-5 w-5" />
        </button>
      </nav>
    </div>
  )
}
