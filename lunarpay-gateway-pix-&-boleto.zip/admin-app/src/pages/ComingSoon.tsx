import { Construction } from 'lucide-react'
import { Card } from '@/components/ui/card'

export default function ComingSoon({ title }: { title: string }) {
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">{title}</h1>
      <Card className="flex flex-col items-center gap-3 py-16 text-center">
        <Construction className="h-9 w-9 text-muted-foreground" strokeWidth={1.5} />
        <div>
          <p className="font-semibold">Esta tela ainda está migrando para o novo painel</p>
          <p className="mt-1 text-sm text-muted">
            Enquanto isso, use a versão anterior em{' '}
            <a className="underline" href={`/admin/${title === 'Produtos' ? 'produtos' : ''}.php`}>
              /admin
            </a>
            .
          </p>
        </div>
      </Card>
    </div>
  )
}
