import * as React from 'react'
import { useQuery } from '@tanstack/react-query'
import { Activity } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { EmptyState } from '@/components/ui/empty-state'
import { Skeleton } from '@/components/ui/skeleton'
import { api } from '@/lib/api'
import { formatDateTime } from '@/lib/utils'

interface AuditoriaResponse {
  events: { event: string; total: number }[]
  logs: { id: number; event: string; actor: string | null; target: string | number | null; ip: string; created_at: string }[]
}

const LABELS: Record<string, string> = {
  user_status_toggled: 'Status de usuário alterado',
  order_refunded: 'Venda reembolsada',
  boleto_created: 'Boleto gerado',
  login_success: 'Login realizado',
  password_changed: 'Senha alterada',
  username_changed: 'Usuário alterado',
  settings_changed: 'Configurações alteradas',
  withdraw_requested: 'Saque solicitado',
  withdraw_approved: 'Saque aprovado',
  withdraw_rejected: 'Saque rejeitado',
  withdraw_failed: 'Saque falhou na LunarPay',
  user_password_reset: 'Senha de usuário redefinida',
  api_token_generated: 'Token de API gerado',
}

export default function Auditoria() {
  const [event, setEvent] = React.useState('')
  const { data, isLoading } = useQuery({
    queryKey: ['auditoria', event],
    queryFn: () => api.get<AuditoriaResponse>(`/api/auditoria.php${event ? `?event=${encodeURIComponent(event)}` : ''}`),
  })

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Trilha de auditoria</h1>
        <p className="text-sm text-muted">Ações administrativas e financeiras registradas sem armazenar segredos.</p>
      </div>

      {data && (
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setEvent('')}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${event === '' ? 'border-white bg-white text-black' : 'border-border-subtle text-muted hover:border-border-hover'}`}
          >
            Todos
          </button>
          {data.events.map((e) => (
            <button
              key={e.event}
              onClick={() => setEvent(e.event)}
              className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${event === e.event ? 'border-white bg-white text-black' : 'border-border-subtle text-muted hover:border-border-hover'}`}
            >
              {LABELS[e.event] ?? e.event} · {e.total}
            </button>
          ))}
        </div>
      )}

      <Card>
        {isLoading ? (
          <div className="flex flex-col gap-2">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
        ) : !data || data.logs.length === 0 ? (
          <EmptyState icon={Activity} title="Nenhum evento registrado" description="As ações administrativas aparecerão aqui." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="pb-3 font-medium">Data</th>
                  <th className="pb-3 font-medium">Evento</th>
                  <th className="pb-3 font-medium">Responsável</th>
                  <th className="pb-3 font-medium">Alvo</th>
                  <th className="pb-3 font-medium">IP</th>
                </tr>
              </thead>
              <tbody>
                {data.logs.map((l) => (
                  <tr key={l.id} className="border-t border-border-subtle">
                    <td className="py-2.5 pr-3 text-xs text-muted">{formatDateTime(l.created_at)}</td>
                    <td className="py-2.5 pr-3 font-medium">{LABELS[l.event] ?? l.event}</td>
                    <td className="py-2.5 pr-3 text-muted">{l.actor ?? 'Sistema'}</td>
                    <td className="py-2.5 pr-3 text-muted">{l.target ?? '—'}</td>
                    <td className="py-2.5 pr-3"><code className="text-xs text-muted-foreground">{l.ip || '—'}</code></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  )
}
