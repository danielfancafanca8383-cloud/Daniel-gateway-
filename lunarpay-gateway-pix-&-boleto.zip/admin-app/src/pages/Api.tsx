import * as React from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { KeyRound, RefreshCw } from 'lucide-react'
import { Card, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CopyButton } from '@/components/ui/copy-button'
import { ConfirmDialog } from '@/components/ui/confirm-dialog'
import { api } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

interface TokenResponse {
  has_token: boolean
  token_preview: string | null
}

export default function Api() {
  const { me } = useAuth()
  const qc = useQueryClient()
  const [freshToken, setFreshToken] = React.useState<string | null>(null)
  const [confirmOpen, setConfirmOpen] = React.useState(false)

  const { data, isLoading } = useQuery({
    queryKey: ['api-token'],
    queryFn: () => api.get<TokenResponse>('/api/token.php'),
  })

  const generateMutation = useMutation({
    mutationFn: () => api.postCsrf<{ token: string; token_preview: string }>('/api/token.php', {}, me!.csrf),
    onSuccess: (data) => {
      setFreshToken(data.token)
      setConfirmOpen(false)
      toast.success('Token gerado. Copie agora — ele não aparece inteiro de novo.')
      qc.invalidateQueries({ queryKey: ['api-token'] })
    },
  })

  const publicOrigin = window.location.origin
  const curlExample = `curl -X POST ${publicOrigin}/api/create_charge.php \\
  -H "Authorization: Bearer ${freshToken ?? data?.token_preview ?? 'SEU_TOKEN'}" \\
  -H "Content-Type: application/json" \\
  -d '{"amount": 25.90, "product_name": "Pedido #123"}'`

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">API deste gateway</h1>
        <p className="text-sm text-muted">
          Token pra integrar um sistema seu (loja, bot, ERP) direto com este painel — gera cobrança Pix por HTTP,
          sem precisar estar logado no navegador. Não confundir com a Ghost Key da LunarPay (essa é do processador,
          fica em Configurações).
        </p>
      </div>

      <Card>
        <CardTitle>Token de acesso</CardTitle>

        {isLoading ? null : freshToken ? (
          <div className="mt-2">
            <div className="rounded-md border border-warning/30 bg-warning/10 px-3 py-2 text-sm text-warning">
              Copie agora — por segurança, esse token completo não vai aparecer de novo.
            </div>
            <div className="mt-3 flex items-center gap-2">
              <code className="flex-1 truncate rounded-md bg-surface-2 px-3 py-2 text-xs">{freshToken}</code>
              <CopyButton value={freshToken} />
            </div>
          </div>
        ) : data?.has_token ? (
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <code className="rounded-md bg-surface-2 px-3 py-2 text-xs text-muted">{data.token_preview}</code>
            <Button variant="outline" size="sm" className="w-auto" onClick={() => setConfirmOpen(true)}>
              <RefreshCw className="h-3.5 w-3.5" /> Gerar novo (revoga o atual)
            </Button>
          </div>
        ) : (
          <div className="mt-2">
            <p className="mb-3 text-sm text-muted">Você ainda não tem um token. Gere um pra começar a integrar.</p>
            <Button size="sm" className="w-auto" loading={generateMutation.isPending} onClick={() => generateMutation.mutate()}>
              <KeyRound className="h-3.5 w-3.5" /> Gerar token
            </Button>
          </div>
        )}
      </Card>

      <Card>
        <CardTitle>Exemplo — criar cobrança Pix</CardTitle>
        <p className="mb-3 text-sm text-muted">Mesmo endpoint que o painel usa em "Gerar Pix", só que autenticado pelo token em vez da sua sessão logada.</p>
        <pre className="overflow-x-auto rounded-md bg-surface-2 p-4 font-mono text-xs text-muted">{curlExample}</pre>
      </Card>

      <Card>
        <CardTitle>Webhook</CardTitle>
        <p className="text-sm text-muted">
          Pagamentos confirmados chegam automaticamente em <code className="rounded bg-surface-2 px-1.5 py-0.5">{publicOrigin}/webhook.php</code> —
          já configurado, não precisa fazer nada além de cadastrar a Ghost Key em Configurações.
        </p>
      </Card>

      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="Gerar novo token?"
        description="O token atual para de funcionar imediatamente. Qualquer integração usando o token antigo vai parar de autenticar."
        confirmLabel="Gerar novo"
        destructive
        loading={generateMutation.isPending}
        onConfirm={() => generateMutation.mutate()}
      />
    </div>
  )
}
