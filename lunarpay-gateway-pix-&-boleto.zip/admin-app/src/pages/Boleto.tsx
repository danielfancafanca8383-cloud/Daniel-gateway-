import * as React from 'react'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Receipt, ArrowLeft } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Label, FieldError } from '@/components/ui/input'
import { CopyButton } from '@/components/ui/copy-button'
import { api, ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'

interface BoletoResponse {
  success: boolean
  external_id: string
  url: string
  barcode: string
  message: string
}

export default function Boleto() {
  const { me } = useAuth()
  const [result, setResult] = React.useState<BoletoResponse | null>(null)
  const [error, setError] = React.useState('')
  const formRef = React.useRef<HTMLFormElement>(null)

  const mutation = useMutation({
    mutationFn: (form: Record<string, string>) => api.postForm<BoletoResponse>('/create_boleto.php', { ...form, csrf: me!.csrf }),
    onSuccess: (data) => {
      setResult(data)
      setError('')
    },
    onError: (e) => {
      const message = e instanceof ApiError ? e.message : 'Falha ao gerar o boleto.'
      setError(message)
      toast.error(message)
    },
  })

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    mutation.mutate({
      amount: String(form.get('amount') || ''),
      name: String(form.get('name') || ''),
      document: String(form.get('document') || ''),
      email: String(form.get('email') || ''),
    })
  }

  if (result) {
    return (
      <div className="mx-auto max-w-md">
        <Card className="glass text-center">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted">Boleto gerado</p>
          <h2 className="mt-2 text-lg font-semibold">Cobrança criada com sucesso</h2>
          <p className="mt-1 text-sm text-muted">{result.message}</p>

          <div className="mt-5 text-left">
            <Label>Linha digitável</Label>
            <div className="flex items-center gap-2">
              <code className="flex-1 truncate rounded-md bg-surface-2 px-3 py-2 text-xs text-muted">{result.barcode || 'Disponível no boleto'}</code>
              <CopyButton value={result.barcode} />
            </div>
          </div>

          {result.url && (
            <a href={result.url} target="_blank" rel="noopener noreferrer">
              <Button variant="secondary" className="mt-4">Abrir boleto</Button>
            </a>
          )}

          <Button variant="ghost" className="mt-3" onClick={() => { setResult(null); formRef.current?.reset() }}>
            <ArrowLeft className="h-4 w-4" /> Gerar outro boleto
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Gerar boleto</h1>
        <p className="text-sm text-muted">Crie uma cobrança bancária com compensação em 1 a 3 dias úteis.</p>
      </div>

      <Card>
        <form ref={formRef} onSubmit={handleSubmit}>
          <Label htmlFor="amount">Valor</Label>
          <Input id="amount" name="amount" type="number" min={5} step="0.01" required />

          <div className="mt-4">
            <Label htmlFor="name">Nome completo</Label>
            <Input id="name" name="name" minLength={3} required />
          </div>

          <div className="mt-4">
            <Label htmlFor="document">CPF ou CNPJ</Label>
            <Input id="document" name="document" inputMode="numeric" required />
          </div>

          <div className="mt-4">
            <Label htmlFor="email">E-mail (opcional)</Label>
            <Input id="email" name="email" type="email" />
          </div>

          <FieldError>{error}</FieldError>

          <Button type="submit" size="checkout" className="mt-6" loading={mutation.isPending}>
            <Receipt className="h-4 w-4" /> Gerar boleto
          </Button>
        </form>
      </Card>
    </div>
  )
}
