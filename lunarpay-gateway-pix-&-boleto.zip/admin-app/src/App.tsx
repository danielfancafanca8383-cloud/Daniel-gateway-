import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'
import { AppShell } from '@/components/layout/AppShell'
import { Skeleton } from '@/components/ui/skeleton'
import Login from '@/pages/Login'
import Registro from '@/pages/Registro'
import Dashboard from '@/pages/Dashboard'
import GerarPix from '@/pages/GerarPix'
import Vendas from '@/pages/Vendas'
import Boleto from '@/pages/Boleto'
import Produtos from '@/pages/Produtos'
import Cupons from '@/pages/Cupons'
import Settings from '@/pages/Settings'
import Conta from '@/pages/Conta'
import Usuarios from '@/pages/Usuarios'
import Auditoria from '@/pages/Auditoria'
import Saque from '@/pages/Saque'
import Taxas from '@/pages/Taxas'
import Api from '@/pages/Api'
import DashboardAdmin from '@/pages/DashboardAdmin'
import SaquesAdmin from '@/pages/SaquesAdmin'

function Protected({ children }: { children: React.ReactNode }) {
  const { me, isLoading } = useAuth()

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Skeleton className="h-10 w-10 rounded-full" />
      </div>
    )
  }
  if (!me) return <Navigate to="/login" replace />
  return <AppShell>{children}</AppShell>
}

function OwnerOnly({ children }: { children: React.ReactNode }) {
  const { me } = useAuth()
  if (!me?.is_owner) return <Navigate to="/" replace />
  return <>{children}</>
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/registro" element={<Registro />} />
      <Route path="/" element={<Protected><Dashboard /></Protected>} />
      <Route path="/gerar-pix" element={<Protected><GerarPix /></Protected>} />
      <Route path="/boleto" element={<Protected><Boleto /></Protected>} />
      <Route path="/vendas" element={<Protected><Vendas /></Protected>} />
      <Route path="/produtos" element={<Protected><Produtos /></Protected>} />
      <Route path="/cupons" element={<Protected><Cupons /></Protected>} />
      <Route path="/settings" element={<Protected><Settings /></Protected>} />
      <Route path="/conta" element={<Protected><Conta /></Protected>} />
      <Route path="/saque" element={<Protected><Saque /></Protected>} />
      <Route path="/taxas" element={<Protected><Taxas /></Protected>} />
      <Route path="/api" element={<Protected><Api /></Protected>} />
      <Route path="/dashboard-geral" element={<Protected><OwnerOnly><DashboardAdmin /></OwnerOnly></Protected>} />
      <Route path="/usuarios" element={<Protected><OwnerOnly><Usuarios /></OwnerOnly></Protected>} />
      <Route path="/saques-admin" element={<Protected><OwnerOnly><SaquesAdmin /></OwnerOnly></Protected>} />
      <Route path="/auditoria" element={<Protected><OwnerOnly><Auditoria /></OwnerOnly></Protected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
