Options -Indexes

<FilesMatch "(^\.|\.(sqlite|db|log|ini|env|bak|sql|md)$)">
    Require all denied
</FilesMatch>

<IfModule mod_headers.c>
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "DENY"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"
    Header always set Cross-Origin-Opener-Policy "same-origin"
</IfModule>

<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{REQUEST_METHOD} ^(TRACE|TRACK)$ [NC]
    RewriteRule .* - [F,L]

    # Alguns SAPIs de PHP (mod_php/FastCGI conforme config) não repassam o
    # header Authorization pra $_SERVER por padrão — precisa forçar aqui
    # pra api/create_charge.php conseguir ler "Bearer <token>" (API própria
    # do gateway, usada por integração externa em admin/app "API").
    RewriteCond %{HTTP:Authorization} ^(.+)$
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%1]

    # Força HTTPS (cadeado). Ignora quando um proxy (Cloudflare etc.) já
    # recebeu em HTTPS e repassa em HTTP, pra não entrar em loop.
    RewriteCond %{HTTPS} off
    RewriteCond %{HTTP:X-Forwarded-Proto} !https
    RewriteCond %{HTTP_HOST} !^(localhost|127\.0\.0\.1)(:\d+)?$ [NC]
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</IfModule>
