import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'LunarPay Gateway Pix & Boleto — Plataforma de Pagamentos',
  description: 'Gateway completo de pagamentos Pix e Boleto em PHP e MySQL/SQLite com checkout, painel administrativo React e API pública.',
  openGraph: {
    title: 'LunarPay Gateway Pix & Boleto — Plataforma de Pagamentos',
    description: 'Gateway completo de pagamentos Pix e Boleto em PHP e MySQL/SQLite com checkout, painel administrativo React e API pública.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'LunarPay Gateway Pix & Boleto — Plataforma de Pagamentos',
    description: 'Gateway completo de pagamentos Pix e Boleto em PHP e MySQL/SQLite com checkout, painel administrativo React e API pública.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
