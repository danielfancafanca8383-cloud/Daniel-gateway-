import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#090a10] text-[#f0f2f8] font-sans">
      {/* Header */}
      <header className="border-b border-white/10 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center font-bold text-white text-xl shadow-lg shadow-indigo-500/20">
            L
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">LunarPay Gateway</h1>
            <p className="text-xs text-white/50">Pix · Boleto · Checkout · Painel Admin</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <a
            href="/admin/login.php"
            className="px-4 py-2 text-sm font-medium rounded-lg bg-white/10 hover:bg-white/15 text-white transition-all"
          >
            Painel Admin
          </a>
          <a
            href="/admin/registro.php"
            className="px-4 py-2 text-sm font-medium rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 transition-all"
          >
            Criar Conta
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-5xl mx-auto px-6 py-20 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-6">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          Gateway de Pagamentos 100% Funcional (PHP & SQLite/MySQL)
        </div>
        <h2 className="text-4xl sm:text-6xl font-extrabold tracking-tight mb-6">
          Receba pagamentos por Pix <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">instantâneos</span>
        </h2>
        <p className="text-lg text-white/70 max-w-2xl mx-auto mb-10">
          Clone completo com links de checkout, cupons de desconto, painel administrativo multi-usuário em React SPA, saques e API pública.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
          <a
            href="/admin/app/"
            className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-xl shadow-indigo-600/25 transition-all"
          >
            Acessar Painel Administrativo
          </a>
          <a
            href="/pagar.php?p=produto-teste"
            className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold transition-all"
          >
            Testar Checkout Pix
          </a>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-indigo-500/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold mb-4">
              ⚡
            </div>
            <h3 className="font-bold text-lg mb-2">Pix Instantâneo</h3>
            <p className="text-sm text-white/60">
              Geração de QR Code e chave Copia e Cola em tempo real com webhook e verificação automática a cada 3 segundos.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold mb-4">
              🛡️
            </div>
            <h3 className="font-bold text-lg mb-2">Painel Multi-Usuário</h3>
            <p className="text-sm text-white/60">
              Painel SPA em React com métricas de vendas, gerenciamento de produtos, cupons promocionais, saques e logs de auditoria.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-pink-500/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center font-bold mb-4">
              🔌
            </div>
            <h3 className="font-bold text-lg mb-2">API para Desenvolvedores</h3>
            <p className="text-sm text-white/60">
              Endpoints completos para criar cobranças (/api/create_charge.php), consultar status e receber webhooks via token Bearer.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
