<?php
/**
 * Wrapper fino em cima da API da LunarPay (https://lunarpay.site).
 * Documentação completa: https://lunarpay.site/api-docs.php
 *
 * Multi-usuário: cada gateway usa sua própria chave, então toda função
 * aqui recebe a chave como parâmetro — nunca lê de uma configuração
 * global (não existe mais "a" chave do sistema, existe a chave de cada
 * usuário, ver includes/db.php e a tabela `users`).
 */
require_once __DIR__ . '/db.php';

define('LUNARPAY_BASE_URL', 'https://lunarpay.site');

function lunarpay_request(string $apiKey, string $method, string $path, ?array $body = null): array
{
    $ch = curl_init(LUNARPAY_BASE_URL . $path);
    $headers = ['Authorization: Bearer ' . $apiKey];

    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    if ($body !== null) {
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $raw      = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    $data = $raw ? (json_decode($raw, true) ?? []) : [];

    return [
        'http_code'  => $httpCode,
        'data'       => $data,
        'curl_error' => $curlErr,
        'raw'        => $raw,
    ];
}

/** Gera uma cobrança Pix real na LunarPay, usando a chave do dono do gateway. */
function lunarpay_create_charge(string $apiKey, float $amount, string $externalId, string $callbackUrl): array
{
    if (strpos($apiKey, 'demo') === 0 || strpos($apiKey, 'test') === 0) {
        $pixCode = '00020101021226840014br.gov.bcb.pix2562pix.lunarpay.site/qr/v2/' . $externalId . '520400005303986540' . sprintf('%0.2f', $amount) . '5802BR5913LUNARPAY6009SAO PAULO62070503***6304ABCD';
        return [
            'http_code' => 200,
            'data' => [
                'pix_id' => 'pix_' . bin2hex(random_bytes(6)),
                'pix_code' => $pixCode,
                'qr_image' => 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' . urlencode($pixCode),
                'amount' => $amount,
                'external_id' => $externalId,
            ],
            'curl_error' => '',
            'raw' => '',
        ];
    }
    return lunarpay_request($apiKey, 'POST', '/api.php', [
        'amount'       => $amount,
        'external_id'  => $externalId,
        'callback_url' => $callbackUrl,
    ]);
}

/** Consulta o status de uma cobrança direto na LunarPay (fallback caso o
 *  webhook nunca chegue — ver aprenda.php da LunarPay, etapa 5). */
function lunarpay_check_status(string $apiKey, string $externalId): array
{
    if (strpos($apiKey, 'demo') === 0 || strpos($apiKey, 'test') === 0) {
        return ['http_code' => 200, 'data' => ['status' => 'pending']];
    }
    return lunarpay_request($apiKey, 'GET', '/check_status.php?external_id=' . urlencode($externalId));
}

function lunarpay_set_nominal(string $apiKey, string $nominal): array
{
    return lunarpay_request($apiKey, 'POST', '/api_set_nominal.php', ['nominal' => $nominal]);
}

function lunarpay_refund(string $apiKey, string $pixId, string $reason): array
{
    return lunarpay_request($apiKey, 'POST', '/api_refund.php', [
        'pix_id' => $pixId,
        'reason' => $reason,
    ]);
}

function lunarpay_create_boleto(string $apiKey, float $amount, string $externalId, array $customer, string $callbackUrl): array
{
    return lunarpay_request($apiKey, 'POST', '/gerar_boleto.php', [
        'amount' => $amount,
        'external_id' => $externalId,
        'callback_url' => $callbackUrl,
        'customer' => $customer,
    ]);
}

function lunarpay_payment_config(string $apiKey): array
{
    return lunarpay_request($apiKey, 'GET', '/api_payment_config.php');
}

/** Saldo disponível/pendente na LunarPay, por método (pix/boleto/cartão). */
function lunarpay_balance(string $apiKey): array
{
    if (strpos($apiKey, 'demo') === 0 || strpos($apiKey, 'test') === 0) {
        return [
            'http_code' => 200,
            'data' => [
                'pix' => ['available' => 1250.80, 'pending' => 240.00],
                'boleto' => ['available' => 450.00, 'pending' => 97.00],
                'credit_card' => ['available' => 0.00, 'pending' => 0.00],
            ],
            'curl_error' => '',
            'raw' => '',
        ];
    }
    return lunarpay_request($apiKey, 'GET', '/api_balance.php');
}

/** Taxa vigente da conta, por rota nominal (percentual, fixa, repasse automático). */
function lunarpay_fees(string $apiKey): array
{
    if (strpos($apiKey, 'demo') === 0 || strpos($apiKey, 'test') === 0) {
        return [
            'http_code' => 200,
            'data' => [
                'nominal1' => ['percent' => 0.99, 'fixed' => 0.00],
                'nominal2' => ['percent' => 1.49, 'fixed' => 0.00],
                'automatic_transfer' => true,
            ],
            'curl_error' => '',
            'raw' => '',
        ];
    }
    return lunarpay_request($apiKey, 'GET', '/api_fees.php');
}

/**
 * Solicita saque de verdade — dinheiro sai da conta LunarPay do usuário via
 * Pix. Só funciona se a conta tiver "Saque via API" habilitado do lado da
 * LunarPay (api_send_enabled); senão volta 403 com mensagem explicando isso.
 */
function lunarpay_withdraw(string $apiKey, float $amount, string $pixKey, string $pixKeyType, string $externalId): array
{
    return lunarpay_request($apiKey, 'POST', '/api_withdraw.php', [
        'amount'      => $amount,
        'pix_key'     => $pixKey,
        'pix_key_type'=> $pixKeyType,
        'external_id' => $externalId,
    ]);
}

function lunarpay_withdraw_status(string $apiKey, string $withdrawalId): array
{
    return lunarpay_request($apiKey, 'GET', '/api_withdraw_status.php?withdrawal_id=' . urlencode($withdrawalId));
}
