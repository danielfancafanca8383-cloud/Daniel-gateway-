<?php
/**
 * Router para o servidor PHP embutido (desenvolvimento e preview).
 * Processa requisições estáticas, rotas SPA do admin/app e arquivos PHP legados.
 */

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
file_put_contents('/tmp/uri.log', date('H:i:s') . ' URI: ' . var_export($uri, true) . ' RAW: ' . var_export($_SERVER['REQUEST_URI'] ?? '', true) . "\n", FILE_APPEND);

// Segurança básica: bloqueia extensões sensíveis
if (preg_match('/\.(sqlite|db|log|ini|env|bak|sql|md)$/i', $uri)) {
    http_response_code(403);
    exit('Acesso proibido.');
}

// Passa cabeçalho Authorization se presente
if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
    // já setado
} elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $_SERVER['HTTP_AUTHORIZATION'] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
}

// MIME types para arquivos estáticos
$mimeTypes = [
    'js'   => 'application/javascript; charset=utf-8',
    'mjs'  => 'application/javascript; charset=utf-8',
    'css'  => 'text/css; charset=utf-8',
    'svg'  => 'image/svg+xml',
    'png'  => 'image/png',
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'gif'  => 'image/gif',
    'webp' => 'image/webp',
    'ico'  => 'image/x-icon',
    'json' => 'application/json',
    'woff' => 'font/woff',
    'woff2'=> 'font/woff2',
    'ttf'  => 'font/ttf',
    'html' => 'text/html; charset=utf-8',
];

function serveStatic(string $path, array $mimeTypes): bool {
    if (file_exists($path) && !is_dir($path)) {
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (isset($mimeTypes[$ext])) {
            header('Content-Type: ' . $mimeTypes[$ext]);
        }
        readfile($path);
        return true;
    }
    return false;
}

// Roteamento especial para o Admin SPA (admin/app/...)
if (strpos($uri, '/admin/app') === 0) {
    $subPath = substr($uri, strlen('/admin/app'));
    $subPath = ltrim($subPath, '/');
    
    // Se solicitou um arquivo estático específico dentro de admin/app
    if ($subPath !== '') {
        $candidate = __DIR__ . '/admin/app/' . $subPath;
        if (file_exists($candidate) && !is_dir($candidate)) {
            serveStatic($candidate, $mimeTypes);
            exit;
        }
    }
    
    // Caso contrário (ex: /admin/app, /admin/app/produtos, /admin/app/vendas, etc.)
    // Retorna o index.html da SPA para o React Router gerenciar
    header('Content-Type: text/html; charset=utf-8');
    require __DIR__ . '/admin/app/index.html';
    exit;
}

// Arquivos estáticos em assets/
if (strpos($uri, '/assets/') === 0) {
    $target = __DIR__ . $uri;
    if (serveStatic($target, $mimeTypes)) {
        exit;
    }
}

// Raiz do admin
if ($uri === '/admin' || $uri === '/admin/') {
    require __DIR__ . '/admin/index.php';
    exit;
}

// Raiz do site
if ($uri === '/' || $uri === '') {
    require __DIR__ . '/index.php';
    exit;
}

// Arquivo físico existente (PHP ou estático)
$target = __DIR__ . $uri;
if (file_exists($target) && !is_dir($target)) {
    $ext = strtolower(pathinfo($target, PATHINFO_EXTENSION));
    if ($ext === 'php') {
        require $target;
        exit;
    } else {
        serveStatic($target, $mimeTypes);
        exit;
    }
}

// Se for diretório com index.php
if (is_dir($target)) {
    if (file_exists($target . '/index.php')) {
        require $target . '/index.php';
        exit;
    }
    if (file_exists($target . '/index.html')) {
        serveStatic($target . '/index.html', $mimeTypes);
        exit;
    }
}

// Tenta com .php no final se omitido (ex: /pagar -> /pagar.php)
if (file_exists($target . '.php')) {
    require $target . '.php';
    exit;
}

http_response_code(404);
echo "404 Not Found";
