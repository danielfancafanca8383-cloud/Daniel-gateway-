<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/lunarpay.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $u = current_user();
    json_out([
        'site_name'          => $u['site_name'],
        'has_api_key'        => $u['lunarpay_api_key'] !== '',
        'has_telegram_bot'   => $u['telegram_bot_token'] !== '',
        'has_telegram_chat'  => $u['telegram_chat_id'] !== '',
        'nominal'            => $u['nominal'],
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();
$user = current_user();
$body = json_body();

$name = trim((string) ($body['site_name'] ?? ''));
$newKey = trim((string) ($body['lunarpay_api_key'] ?? ''));
$newBot = trim((string) ($body['telegram_bot_token'] ?? ''));
$newChat = trim((string) ($body['telegram_chat_id'] ?? ''));
$clearTelegram = !empty($body['clear_telegram']);
$bot = $clearTelegram ? '' : ($newBot !== '' ? $newBot : (string) $user['telegram_bot_token']);
$chat = $clearTelegram ? '' : ($newChat !== '' ? $newChat : (string) $user['telegram_chat_id']);
$nominal = (string) ($body['nominal'] ?? 'nominal1');
$key = $newKey !== '' ? $newKey : (string) $user['lunarpay_api_key'];

if ($name === '' || mb_strlen($name) > 80) {
    json_error('Informe um nome válido para o gateway.', 422);
}
if ($newKey !== '' && !preg_match('/^ghost_[A-Za-z0-9_-]{12,}$/', $newKey)) {
    json_error('A chave LunarPay deve começar com ghost_.', 422);
}
if (!in_array($nominal, ['nominal1', 'nominal3', 'nominal7'], true)) {
    json_error('Rota de processamento inválida.', 422);
}

if ($key !== '' && $nominal !== ($user['nominal'] ?? 'nominal1')) {
    $route = lunarpay_set_nominal($key, $nominal);
    if ($route['http_code'] < 200 || $route['http_code'] >= 300 || empty($route['data']['success'])) {
        json_error($route['data']['error'] ?? 'A LunarPay não aceitou a alteração da rota.', 422);
    }
}

db()->prepare('UPDATE users SET site_name = ?, lunarpay_api_key = ?, telegram_bot_token = ?, telegram_chat_id = ?, nominal = ? WHERE id = ?')
    ->execute([$name, $key, $bot, $chat, $nominal, current_user_id()]);
audit_event(current_user_id(), 'settings_changed', current_user_id(), client_ip());

json_out(['ok' => true]);
