<?php
/**
 * Seeder inicial para o LunarPay Gateway.
 * Cria o proprietário padrão e produtos de demonstração para o preview.
 */
require_once __DIR__ . '/includes/db.php';

$pdo = db();

// Verifica se já existe um owner
$count = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn();

if ($count === 0) {
    $passHash = password_hash('Admin12345678', PASSWORD_DEFAULT);
    $apiToken = 'gwk_' . bin2hex(random_bytes(24));
    
    $stmt = $pdo->prepare(
        "INSERT INTO users (username, password_hash, site_name, lunarpay_api_key, role, active, nominal, api_token)
         VALUES (?, ?, ?, ?, 'owner', 1, 'nominal1', ?)"
    );
    $stmt->execute(['admin', $passHash, 'LunarPay Gateway', 'demo_lunar_key', $apiToken]);
    $ownerId = (int) $pdo->lastInsertId();

    // Produtos de exemplo
    $p1 = $pdo->prepare(
        "INSERT INTO products (user_id, slug, name, description, price, stock, active)
         VALUES (?, 'plano-pro', 'Plano Pro — Assinatura Digital', 'Acesso completo a todas as ferramentas e integrações do portal com suporte exclusivo.', 29.90, 50, 1)"
    );
    $p1->execute([$ownerId]);

    $p2 = $pdo->prepare(
        "INSERT INTO products (user_id, slug, name, description, price, stock, active)
         VALUES (?, 'curso-gateway', 'Curso Dominando Gateways Pix', 'Treinamento prático do zero ao avançado para vender infoprodutos e serviços na internet.', 97.00, 100, 1)"
    );
    $p2->execute([$ownerId]);

    // Cupom de exemplo
    $c1 = $pdo->prepare(
        "INSERT INTO coupons (user_id, code, percent_off, active, uses)
         VALUES (?, 'DESCONTO10', 10.0, 1, 0)"
    );
    $c1->execute([$ownerId]);

    // Pedidos de exemplo para alimentar as métricas do painel administrativo
    $orders = [
        ['ord_' . bin2hex(random_bytes(8)), 29.90, 'Plano Pro — Assinatura Digital', 'Carlos Eduardo', 'paid', '-2 hours', 'pix'],
        ['ord_' . bin2hex(random_bytes(8)), 97.00, 'Curso Dominando Gateways Pix', 'Mariana Souza', 'paid', '-5 hours', 'pix'],
        ['ord_' . bin2hex(random_bytes(8)), 29.90, 'Plano Pro — Assinatura Digital', 'Felipe Santos', 'paid', '-1 day', 'pix'],
        ['ord_' . bin2hex(random_bytes(8)), 45.00, 'Cobrança Avulsa', 'Lucas Ribeiro', 'paid', '-2 days', 'pix'],
        ['ord_' . bin2hex(random_bytes(8)), 97.00, 'Curso Dominando Gateways Pix', 'Ana Paula', 'pending', '-30 minutes', 'pix'],
    ];

    foreach ($orders as $ord) {
        $stmtOrd = $pdo->prepare(
            "INSERT INTO orders (user_id, external_id, pix_id, amount, product_name, customer_name, status, created_at, paid_at, payment_method)
             VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now', ?), datetime('now', ?), ?)"
        );
        $paidAt = $ord[4] === 'paid' ? $ord[5] : null;
        $stmtOrd->execute([
            $ownerId,
            $ord[0],
            'pix_' . bin2hex(random_bytes(6)),
            $ord[1],
            $ord[2],
            $ord[3],
            $ord[4],
            $ord[5],
            $paidAt,
            $ord[6]
        ]);
    }

    echo "Banco de dados inicializado com sucesso! Usuário: admin | Senha: Admin12345678\n";
} else {
    echo "Usuário owner já existente no banco de dados.\n";
}
