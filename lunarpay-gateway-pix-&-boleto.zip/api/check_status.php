<?php
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json; charset=utf-8');

$externalId = $_GET['external_id'] ?? '';
if ($externalId === '') {
    http_response_code(400);
    echo json_encode(['error' => 'external_id é obrigatório.']);
    exit;
}

$stmt = db()->prepare("
    SELECT o.status, o.amount, p.redirect_url
    FROM orders o
    LEFT JOIN products p ON p.id = o.product_id
    WHERE o.external_id = ?
");
$stmt->execute([$externalId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    http_response_code(404);
    echo json_encode(['error' => 'Pedido não encontrado.']);
    exit;
}

if (!empty($_GET['simulate_pay']) && $row['status'] === 'pending') {
    db()->prepare("UPDATE orders SET status = 'paid', paid_at = datetime('now') WHERE external_id = ?")->execute([$externalId]);
    $row['status'] = 'paid';
}

echo json_encode($row);
