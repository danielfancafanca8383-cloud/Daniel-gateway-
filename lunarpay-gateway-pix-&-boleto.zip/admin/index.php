<?php
require_once __DIR__ . '/../includes/auth.php';

// Instalação nova (sem proprietário ainda) — manda pro setup antes de
// qualquer coisa, senão quem acabou de subir os arquivos cai direto na
// tela de login da SPA sem nunca ter visto a tela de criar a conta dona.
if ((int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn() === 0) {
    header('Location: setup.php');
    exit;
}

// Painel novo é a SPA React em admin/app/ — esta página fica só como
// fallback de compatibilidade (link antigo salvo, bookmark, etc.). O
// dashboard de verdade (dados, gráfico, checklist) agora vive em
// admin/api/dashboard.php + admin-app/src/pages/Dashboard.tsx.
header('Location: app/');
exit;
