<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/lunarpay.php';
require_login();
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error'=>'Método não permitido.']); exit; }
check_csrf();
if (rate_limit_hit('boleto', (string) current_user_id(), 10, 10)) { http_response_code(429); echo json_encode(['error'=>'Muitas tentativas. Aguarde alguns minutos.']); exit; }
$amount = round((float) ($_POST['amount'] ?? 0), 2);
$name = trim((string) ($_POST['name'] ?? ''));
$document = preg_replace('/\D/', '', (string) ($_POST['document'] ?? ''));
$email = trim((string) ($_POST['email'] ?? ''));
if ($amount < 5 || $amount > 100000 || mb_strlen($name) < 3 || !in_array(strlen($document), [11,14], true) || ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL))) { http_response_code(422); echo json_encode(['error'=>'Revise valor, nome, CPF/CNPJ e e-mail.']); exit; }
$user = current_user();
if (empty($user['lunarpay_api_key'])) { http_response_code(422); echo json_encode(['error'=>'Configure sua Ghost Key primeiro.']); exit; }
$externalId = 'bol_' . bin2hex(random_bytes(10));
try { $callback = application_origin().'/webhook.php'; } catch (RuntimeException $e) { http_response_code(400); echo json_encode(['error'=>'Domínio da requisição inválido.']); exit; }
$res = lunarpay_create_boleto((string)$user['lunarpay_api_key'], $amount, $externalId, ['name'=>$name,'document'=>$document,'email'=>$email], $callback);
$data = $res['data'];
if ($res['http_code'] < 200 || $res['http_code'] >= 300 || empty($data['success'])) { http_response_code(422); echo json_encode(['error'=>$data['error'] ?? 'Não foi possível gerar o boleto.']); exit; }
$boletoId = (string) ($data['boleto_id'] ?? $data['id'] ?? '');
$url = (string) ($data['boleto_url'] ?? $data['url'] ?? '');
$code = (string) ($data['bar_code'] ?? $data['barcode'] ?? $data['barCode'] ?? '');
db()->prepare("INSERT INTO orders (user_id,external_id,pix_id,amount,product_name,customer_name,status,payment_method,payment_url,payment_code) VALUES (?,?,?,?,?,?,'pending','boleto',?,?)")->execute([current_user_id(),$externalId,$boletoId,$amount,'Cobrança por boleto',$name,$url,$code]);
audit_event(current_user_id(),'boleto_created',(int)db()->lastInsertId(),client_ip());
echo json_encode(['success'=>true,'external_id'=>$externalId,'url'=>$url,'barcode'=>$code,'message'=>$data['message'] ?? 'Compensação estimada em 1 a 3 dias úteis.']);
