<?php
require_once __DIR__ . '/../includes/auth.php';

// Em instalação nova, o primeiro acesso configura o único administrador —
// setup.php não tem equivalente na SPA, então isso continua servido aqui.
if ((int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn() === 0) {
    header('Location: setup.php');
    exit;
}

// Painel novo é a SPA React (admin/api/login.php faz a autenticação de
// verdade agora) — esta página fica só como fallback de compatibilidade
// pra quem tinha o link antigo salvo.
header('Location: app/login');
exit;
