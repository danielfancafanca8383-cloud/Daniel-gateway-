<?php
require_once __DIR__ . '/../includes/auth.php';

if ((int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn() > 0) {
    header('Location: login.php');
    exit;
}

$error = '';
$username = '';
$siteName = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $username = strtolower(trim($_POST['username'] ?? ''));
    $siteName = trim($_POST['site_name'] ?? '');
    $pass = (string) ($_POST['pass'] ?? '');
    $pass2 = (string) ($_POST['pass2'] ?? '');

    if (!preg_match('/^[a-z0-9_.-]{3,30}$/', $username)) {
        $error = 'Usuário inválido. Use entre 3 e 30 caracteres (letras, números, ponto ou traço).';
    } elseif ($siteName === '') {
        $error = 'Informe o nome da plataforma.';
    } elseif (strlen($pass) < 6) {
        $error = 'A senha precisa ter pelo menos 6 caracteres.';
    } elseif ($pass !== $pass2) {
        $error = 'As senhas não coincidem. Verifique e tente novamente.';
    } else {
        try {
            $apiToken = 'gwk_' . bin2hex(random_bytes(24));
            db()->prepare("INSERT INTO users (username, password_hash, site_name, role, active, nominal, api_token) VALUES (?, ?, ?, 'owner', 1, 'nominal1', ?)")
                ->execute([$username, password_hash($pass, PASSWORD_DEFAULT), $siteName, $apiToken]);
            $newUserId = (int) db()->lastInsertId();
            session_regenerate_id(true);
            $_SESSION['user_id'] = $newUserId;

            // Produto e cupom de exemplo inicial vinculados ao novo proprietário
            db()->prepare(
                "INSERT INTO products (user_id, slug, name, description, price, stock, active)
                 VALUES (?, 'produto-digital', 'Produto Digital', 'Produto criado automaticamente na sua nova plataforma.', 29.90, 100, 1)"
            )->execute([$newUserId]);

            db()->prepare(
                "INSERT INTO coupons (user_id, code, percent_off, active, uses)
                 VALUES (?, 'DESCONTO10', 10.0, 1, 0)"
            )->execute([$newUserId]);

            header('Location: app/');
            exit;
        } catch (PDOException $e) {
            $error = 'O proprietário da plataforma já foi configurado.';
        }
    }
}
$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LunarPay - Configuração Inicial</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }

    body {
      background-color: #06070a;
      color: #ffffff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    .card {
      background: rgba(13, 14, 20, 0.95);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      padding: 32px 26px;
      width: 100%;
      max-width: 400px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8);
    }

    .header {
      text-align: center;
      margin-bottom: 24px;
    }

    .avatar-icon {
      width: 52px;
      height: 52px;
      background: rgba(255, 255, 255, 0.08);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 12px;
      font-weight: 600;
      font-size: 20px;
      color: #ffffff;
      border: 1px solid rgba(255, 255, 255, 0.15);
    }

    .title {
      font-size: 22px;
      font-weight: 700;
      margin-bottom: 6px;
    }

    .subtitle {
      font-size: 13px;
      color: #94a3b8;
    }

    .form-group {
      margin-bottom: 18px;
    }

    .label {
      display: block;
      font-size: 12px;
      color: #94a3b8;
      margin-bottom: 8px;
    }

    .input-wrapper {
      position: relative;
      display: flex;
      align-items: center;
    }

    .input {
      width: 100%;
      padding: 12px 40px 12px 14px;
      background: #101117;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #ffffff;
      font-size: 14px;
      outline: none;
      transition: all 0.3s ease;
    }

    .input:focus {
      border-color: #7c3aed;
      box-shadow: 0 0 14px rgba(124, 58, 237, 0.4);
    }

    .toggle-eye {
      position: absolute;
      right: 12px;
      background: none;
      border: none;
      color: #6b7280;
      cursor: pointer;
      font-size: 14px;
    }

    /* MEDIDOR DE SENHA */
    .strength-wrapper {
      margin-top: 8px;
    }

    .strength-bar-bg {
      width: 100%;
      height: 4px;
      background: rgba(255, 255, 255, 0.08);
      border-radius: 4px;
      overflow: hidden;
    }

    .strength-bar-fill {
      height: 100%;
      width: 0%;
      border-radius: 4px;
      transition: width 0.4s ease, background-color 0.4s ease;
    }

    .strength-text {
      font-size: 11px;
      margin-top: 4px;
      color: #6b7280;
      text-align: right;
    }

    /* BOTÃO COM ONDAS */
    .btn-submit-container {
      position: relative;
      width: 100%;
      height: 48px;
      margin-top: 16px;
      border-radius: 12px;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .btn-wave-canvas {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
    }

    .btn-submit-text {
      position: relative;
      z-index: 2;
      color: #ffffff;
      font-weight: 600;
      font-size: 15px;
      background: transparent;
      border: none;
      width: 100%;
      height: 100%;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .footer-text {
      text-align: center;
      font-size: 11px;
      color: #64748b;
      margin-top: 18px;
    }

    .error-box {
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #fca5a5;
      padding: 10px 14px;
      border-radius: 10px;
      font-size: 12px;
      margin-bottom: 16px;
    }
  </style>
</head>
<body>

  <div class="card">
    <div class="header">
      <div class="avatar-icon">G</div>
      <h1 class="title">Configuração inicial</h1>
      <p class="subtitle">Crie o proprietário da plataforma</p>
    </div>

    <?php if ($error): ?>
      <div class="error-box"><?php echo htmlspecialchars($error, ENT_QUOTES); ?></div>
    <?php endif; ?>
    <div id="clientErrorBox" class="error-box" style="display: none;"></div>

    <form method="POST" onsubmit="return handleSubmit(event)">
      <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($csrf, ENT_QUOTES); ?>">

      <div class="form-group">
        <label class="label">Usuário do proprietário</label>
        <div class="input-wrapper">
          <input 
            type="text" 
            name="username" 
            class="input" 
            placeholder="ex: Daniel" 
            value="<?php echo htmlspecialchars($username, ENT_QUOTES); ?>" 
            required 
            maxlength="30"
            autofocus
          >
        </div>
      </div>

      <div class="form-group">
        <label class="label">Nome da plataforma</label>
        <div class="input-wrapper">
          <input 
            type="text" 
            name="site_name" 
            class="input" 
            placeholder="ex: Zukify" 
            value="<?php echo htmlspecialchars($siteName, ENT_QUOTES); ?>" 
            required 
            maxlength="80"
          >
        </div>
      </div>

      <!-- SENHA -->
      <div class="form-group">
        <label class="label">Senha (mínimo 6 caracteres)</label>
        <div class="input-wrapper">
          <input 
            type="password" 
            id="passInput" 
            name="pass" 
            class="input" 
            placeholder="••••••••" 
            minlength="6"
            required
            autocomplete="new-password"
          >
          <button type="button" class="toggle-eye" onclick="togglePass('passInput', this)">👁️</button>
        </div>
        
        <div class="strength-wrapper">
          <div class="strength-bar-bg">
            <div id="strengthBar" class="strength-bar-fill"></div>
          </div>
          <div id="strengthText" class="strength-text">Introduza uma senha</div>
        </div>
      </div>

      <!-- CONFIRMAR SENHA -->
      <div class="form-group">
        <label class="label">Confirme a senha</label>
        <div class="input-wrapper">
          <input 
            type="password" 
            id="confirmInput" 
            name="pass2" 
            class="input" 
            placeholder="••••••••" 
            minlength="6"
            required
            autocomplete="new-password"
          >
          <button type="button" class="toggle-eye" onclick="togglePass('confirmInput', this)">👁️</button>
        </div>
      </div>

      <!-- BOTÃO DE SUBMISSÃO COM ONDAS -->
      <div class="btn-submit-container">
        <canvas id="btnWaveCanvas" class="btn-wave-canvas"></canvas>
        <button type="submit" class="btn-submit-text" id="submitBtn">
          Criar proprietário ➔
        </button>
      </div>
    </form>

    <p class="footer-text">Esta etapa aparece somente na primeira instalação</p>
  </div>

  <script>
    // Toggle Mostrar/Ocultar Senha
    function togglePass(inputId, btn) {
      const input = document.getElementById(inputId);
      if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = '🙈';
      } else {
        input.type = 'password';
        btn.textContent = '👁️';
      }
    }

    // Força da Senha
    const passInput = document.getElementById('passInput');
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    const clientErrorBox = document.getElementById('clientErrorBox');

    passInput.addEventListener('input', () => {
      const val = passInput.value;
      let score = 0;
      if (!val) {
        strengthBar.style.width = '0%';
        strengthText.textContent = 'Introduza uma senha';
        strengthText.style.color = '#6b7280';
        return;
      }
      if (val.length >= 6) score += 1;
      if (val.length >= 10) score += 1;
      if (/[A-Z]/.test(val)) score += 1;
      if (/[0-9]/.test(val)) score += 1;

      if (score <= 1) {
        strengthBar.style.width = '30%';
        strengthBar.style.backgroundColor = '#ef4444';
        strengthText.textContent = 'Senha Fraca';
        strengthText.style.color = '#ef4444';
      } else if (score <= 3) {
        strengthBar.style.width = '65%';
        strengthBar.style.backgroundColor = '#f59e0b';
        strengthText.textContent = 'Senha Média';
        strengthText.style.color = '#f59e0b';
      } else {
        strengthBar.style.width = '100%';
        strengthBar.style.backgroundColor = '#10b981';
        strengthText.textContent = 'Senha Forte';
        strengthText.style.color = '#10b981';
      }
    });

    // Animação de Ondas no Botão
    const canvas = document.getElementById('btnWaveCanvas');
    const ctx = canvas.getContext('2d');
    let width = 0, height = 0, step = 0;

    function resize() {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.offsetWidth;
      height = canvas.height = canvas.parentElement.offsetHeight;
    }
    window.addEventListener('resize', resize);
    window.addEventListener('load', resize);
    resize();

    function draw() {
      if (!ctx || width === 0 || height === 0) {
        resize();
        requestAnimationFrame(draw);
        return;
      }
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = '#1e40af';
      ctx.fillRect(0, 0, width, height);

      step += 0.04;

      ctx.beginPath();
      ctx.moveTo(0, height);
      for (let x = 0; x <= width; x += 10) {
        let y = Math.sin(x * 0.02 + step) * 5 + height * 0.4;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(width, height);
      ctx.fillStyle = 'rgba(59, 130, 246, 0.7)';
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(0, height);
      for (let x = 0; x <= width; x += 10) {
        let y = Math.cos(x * 0.025 - step) * 6 + height * 0.5;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(width, height);
      ctx.fillStyle = 'rgba(124, 58, 237, 0.8)';
      ctx.fill();

      requestAnimationFrame(draw);
    }
    draw();

    function handleSubmit(e) {
      const pass = passInput.value;
      const confirmPass = document.getElementById('confirmInput').value;

      if (pass !== confirmPass) {
        e.preventDefault();
        clientErrorBox.style.display = 'block';
        clientErrorBox.textContent = 'As senhas não coincidem. Verifique e tente novamente.';
        return false;
      }
      clientErrorBox.style.display = 'none';
      return true;
    }
  </script>
</body>
</html>
