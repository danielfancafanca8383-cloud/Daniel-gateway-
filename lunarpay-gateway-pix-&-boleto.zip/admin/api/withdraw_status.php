<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/lunarpay.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

$user = current_user();
if ($user['lunarpay_api_key'] === '') {
    json_error('Cadastre sua chave da LunarPay em Configurações primeiro.', 422);
}

$withdrawalId = trim((string) ($_GET['withdrawal_id'] ?? ''));
if ($withdrawalId === '') {
    json_error('Informe withdrawal_id.', 422);
}

$res = lunarpay_withdraw_status($user['lunarpay_api_key'], $withdrawalId);
if ($res['http_code'] < 200 || $res['http_code'] >= 300 || empty($res['data']['success'])) {
    json_error($res['data']['error'] ?? 'Não foi possível consultar o status do saque.', $res['http_code'] >= 400 ? $res['http_code'] : 502);
}

json_out($res['data']);
