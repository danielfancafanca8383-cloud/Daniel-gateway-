<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/uploads.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

function slugify(string $s): string
{
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';
    $s = trim($s, '-');
    return $s !== '' ? $s : 'produto';
}

function sanitize_redirect_url(string $url): string
{
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('#^https?://#i', $url)) return '';
    return $url;
}

function product_out(array $p, string $baseUrl): array
{
    return [
        'id'           => (int) $p['id'],
        'slug'         => $p['slug'],
        'name'         => $p['name'],
        'description'  => $p['description'],
        'price'        => (float) $p['price'],
        'image_path'   => $p['image_path'],
        'stock'        => $p['stock'] === null ? null : (int) $p['stock'],
        'redirect_url' => $p['redirect_url'],
        'active'       => (bool) $p['active'],
        'link'         => $baseUrl . '/pagar.php?p=' . urlencode($p['slug']),
    ];
}

$uid = current_user_id();
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$baseUrl = $scheme . ($_SERVER['HTTP_HOST'] ?? 'localhost');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = db()->prepare("SELECT * FROM products WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$uid]);
    json_out(array_map(static fn($p) => product_out($p, $baseUrl), $stmt->fetchAll(PDO::FETCH_ASSOC)));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();
$action = $_POST['action'] ?? '';

if ($action === 'create') {
    $name        = trim($_POST['name'] ?? '');
    $price       = (float) ($_POST['price'] ?? 0);
    $desc        = trim($_POST['description'] ?? '');
    $stockRaw    = trim($_POST['stock'] ?? '');
    $stock       = $stockRaw === '' ? null : max(0, (int) $stockRaw);
    $redirectUrl = sanitize_redirect_url($_POST['redirect_url'] ?? '');

    if ($name === '') json_error('Dê um nome pro produto.', 422);
    if ($price < 5) json_error('O valor mínimo é R$ 5,00 (é o mínimo aceito pela LunarPay).', 422);

    $imagePath = null;
    try {
        $imagePath = handle_product_image_upload($_FILES['image'] ?? []);
    } catch (RuntimeException $e) {
        if ($e->getMessage() !== '__NO_FILE__') json_error($e->getMessage(), 422);
    }

    $baseSlug = slugify($name);
    $slug = $baseSlug;
    $check = db()->prepare("SELECT COUNT(*) FROM products WHERE slug = ?");
    $i = 1;
    do {
        $check->execute([$slug]);
        if ((int) $check->fetchColumn() === 0) break;
        $i++;
        $slug = $baseSlug . '-' . $i;
    } while (true);

    db()->prepare("INSERT INTO products (user_id, slug, name, description, price, image_path, stock, redirect_url, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)")
        ->execute([$uid, $slug, $name, $desc, $price, $imagePath, $stock, $redirectUrl ?: null]);

    $newId = (int) db()->lastInsertId();
    $stmt = db()->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$newId]);
    json_out(product_out($stmt->fetch(PDO::FETCH_ASSOC), $baseUrl), 201);
}

if ($action === 'update') {
    $id          = (int) ($_POST['id'] ?? 0);
    $price       = (float) ($_POST['price'] ?? 0);
    $desc        = trim($_POST['description'] ?? '');
    $stockRaw    = trim($_POST['stock'] ?? '');
    $stock       = $stockRaw === '' ? null : max(0, (int) $stockRaw);
    $redirectUrl = sanitize_redirect_url($_POST['redirect_url'] ?? '');

    $ownStmt = db()->prepare("SELECT * FROM products WHERE id = ? AND user_id = ?");
    $ownStmt->execute([$id, $uid]);
    $existing = $ownStmt->fetch(PDO::FETCH_ASSOC);

    if (!$existing) json_error('Produto não encontrado.', 404);
    if ($price < 5) json_error('O valor mínimo é R$ 5,00.', 422);

    $newImagePath = $existing['image_path'];
    try {
        $uploaded = handle_product_image_upload($_FILES['image'] ?? []);
        delete_product_image($existing['image_path']);
        $newImagePath = $uploaded;
    } catch (RuntimeException $e) {
        if ($e->getMessage() !== '__NO_FILE__') json_error($e->getMessage(), 422);
    }

    db()->prepare("UPDATE products SET price = ?, description = ?, image_path = ?, stock = ?, redirect_url = ? WHERE id = ? AND user_id = ?")
        ->execute([$price, $desc, $newImagePath, $stock, $redirectUrl ?: null, $id, $uid]);

    $stmt = db()->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    json_out(product_out($stmt->fetch(PDO::FETCH_ASSOC), $baseUrl));
}

if ($action === 'toggle') {
    $id = (int) ($_POST['id'] ?? 0);
    $stmt = db()->prepare("UPDATE products SET active = 1 - active WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $uid]);
    if ($stmt->rowCount() === 0) json_error('Produto não encontrado.', 404);
    json_out(['ok' => true]);
}

if ($action === 'delete') {
    $id = (int) ($_POST['id'] ?? 0);
    $imgStmt = db()->prepare("SELECT image_path FROM products WHERE id = ? AND user_id = ?");
    $imgStmt->execute([$id, $uid]);
    $row = $imgStmt->fetch(PDO::FETCH_ASSOC);
    if ($row === false) json_error('Produto não encontrado.', 404);
    db()->prepare("DELETE FROM products WHERE id = ? AND user_id = ?")->execute([$id, $uid]);
    if ($row['image_path']) delete_product_image($row['image_path']);
    json_out(['ok' => true]);
}

json_error('Ação inválida.', 400);
