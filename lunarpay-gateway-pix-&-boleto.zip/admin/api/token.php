<?php
/**
 * Token de API DESTE gateway (não confundir com a Ghost Key da LunarPay,
 * que é a chave do processador). Esse token deixa o dono do gateway
 * integrar sistema externo dele com o próprio painel — ex: criar cobrança
 * Pix via HTTP sem precisar estar logado no navegador.
 *
 * Igual às outras credenciais do projeto (Ghost Key, token do Telegram),
 * o valor salvo nunca é devolvido inteiro de novo — só mascarado. O valor
 * cheio só aparece uma vez, na resposta do POST que acabou de gerá-lo.
 */
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

function mask_token(string $token): string
{
    return substr($token, 0, 8) . str_repeat('•', 12) . substr($token, -4);
}

$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $token = (string) ($user['api_token'] ?? '');
    json_out([
        'has_token'     => $token !== '',
        'token_preview' => $token !== '' ? mask_token($token) : null,
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();

$newToken = 'gwk_' . bin2hex(random_bytes(24));
db()->prepare("UPDATE users SET api_token = ? WHERE id = ?")->execute([$newToken, current_user_id()]);
audit_event(current_user_id(), 'api_token_generated', current_user_id(), client_ip());

json_out([
    'token'         => $newToken,
    'token_preview' => mask_token($newToken),
]);
