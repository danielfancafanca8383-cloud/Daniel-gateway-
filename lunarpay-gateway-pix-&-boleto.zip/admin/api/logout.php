<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login();
$_SESSION = [];
session_destroy();
json_out(['ok' => true]);
