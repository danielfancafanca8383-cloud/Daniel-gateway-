<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';
require_login_json();

$uid = current_user_id();

function coupon_out(array $c): array
{
    return [
        'id'          => (int) $c['id'],
        'code'        => $c['code'],
        'percent_off' => (float) $c['percent_off'],
        'active'      => (bool) $c['active'],
        'uses'        => (int) $c['uses'],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = db()->prepare("SELECT * FROM coupons WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$uid]);
    json_out(array_map('coupon_out', $stmt->fetchAll(PDO::FETCH_ASSOC)));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();
$body = json_body();
$action = $body['action'] ?? '';

if ($action === 'create') {
    $code       = strtoupper(trim($body['code'] ?? ''));
    $percentOff = (float) ($body['percent_off'] ?? 0);

    if ($code === '' || !preg_match('/^[A-Z0-9_-]{3,40}$/', $code)) {
        json_error('Código inválido — use só letras, números, "-" ou "_" (3 a 40 caracteres).', 422);
    }
    if ($percentOff <= 0 || $percentOff > 90) {
        json_error('O desconto precisa ser entre 1% e 90%.', 422);
    }

    $check = db()->prepare("SELECT COUNT(*) FROM coupons WHERE code = ? AND user_id = ?");
    $check->execute([$code, $uid]);
    if ((int) $check->fetchColumn() > 0) json_error('Já existe um cupom com esse código.', 409);

    db()->prepare("INSERT INTO coupons (user_id, code, percent_off, active) VALUES (?, ?, ?, 1)")
        ->execute([$uid, $code, $percentOff]);

    $stmt = db()->prepare("SELECT * FROM coupons WHERE id = ?");
    $stmt->execute([(int) db()->lastInsertId()]);
    json_out(coupon_out($stmt->fetch(PDO::FETCH_ASSOC)), 201);
}

if ($action === 'toggle') {
    $id = (int) ($body['id'] ?? 0);
    $stmt = db()->prepare("UPDATE coupons SET active = 1 - active WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $uid]);
    if ($stmt->rowCount() === 0) json_error('Cupom não encontrado.', 404);
    json_out(['ok' => true]);
}

if ($action === 'delete') {
    $id = (int) ($body['id'] ?? 0);
    $stmt = db()->prepare("DELETE FROM coupons WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $uid]);
    if ($stmt->rowCount() === 0) json_error('Cupom não encontrado.', 404);
    json_out(['ok' => true]);
}

json_error('Ação inválida.', 400);
