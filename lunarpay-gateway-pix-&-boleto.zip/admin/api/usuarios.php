<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/json_api.php';

if (empty($_SESSION['user_id'])) json_error('unauthenticated', 401);
if (!current_user_is_owner()) json_error('forbidden', 403);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $search = trim((string) ($_GET['q'] ?? ''));
    $sql = "SELECT u.id,u.username,u.site_name,u.active,u.nominal,u.created_at,u.lunarpay_api_key,
            COUNT(DISTINCT o.id) orders_count, COALESCE(SUM(CASE WHEN o.status='paid' THEN o.amount ELSE 0 END),0) volume
            FROM users u LEFT JOIN orders o ON o.user_id=u.id WHERE u.role='user'";
    $params = [];
    if ($search !== '') { $sql .= ' AND (u.username LIKE ? OR u.site_name LIKE ?)'; $params = ["%$search%", "%$search%"]; }
    $sql .= ' GROUP BY u.id ORDER BY u.id DESC LIMIT 200';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $totals = db()->query("SELECT COUNT(*) total, SUM(CASE WHEN active=1 THEN 1 ELSE 0 END) active FROM users WHERE role='user'")->fetch(PDO::FETCH_ASSOC);

    json_out([
        'totals' => ['total' => (int) $totals['total'], 'active' => (int) $totals['active']],
        'users'  => array_map(static fn($u) => [
            'id'            => (int) $u['id'],
            'username'      => $u['username'],
            'site_name'     => $u['site_name'],
            'active'        => (bool) $u['active'],
            'nominal'       => $u['nominal'],
            'created_at'    => $u['created_at'],
            'has_api_key'   => $u['lunarpay_api_key'] !== '',
            'orders_count'  => (int) $u['orders_count'],
            'volume'        => (float) $u['volume'],
        ], $users),
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Método não permitido.', 405);
}

check_csrf_header();
$body = json_body();
$targetId = (int) ($body['user_id'] ?? 0);
$action = $body['action'] ?? 'toggle';

if (!$targetId || $targetId === current_user_id()) {
    json_error('Usuário não encontrado.', 404);
}

$check = db()->prepare("SELECT id FROM users WHERE id = ? AND role = 'user'");
$check->execute([$targetId]);
if (!$check->fetchColumn()) {
    json_error('Usuário não encontrado.', 404);
}

if ($action === 'toggle') {
    db()->prepare("UPDATE users SET active = CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id = ?")->execute([$targetId]);
    audit_event(current_user_id(), 'user_status_toggled', $targetId, client_ip());
    json_out(['ok' => true]);
}

if ($action === 'reset_password') {
    $temp = bin2hex(random_bytes(5));
    db()->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([password_hash($temp, PASSWORD_DEFAULT), $targetId]);
    audit_event(current_user_id(), 'user_password_reset', $targetId, client_ip());
    json_out(['ok' => true, 'temp_password' => $temp]);
}

json_error('Ação inválida.', 400);
