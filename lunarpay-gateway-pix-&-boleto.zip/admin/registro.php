<?php
require_once __DIR__ . '/../includes/auth.php';

if ((int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'owner'")->fetchColumn() === 0) {
    header('Location: setup.php');
    exit;
}

// Painel novo é a SPA React (admin/api/registro.php faz o cadastro de
// verdade agora) — esta página fica só como fallback de compatibilidade.
header('Location: app/registro');
exit;
