<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/lunarpay.php';
require_login();
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido.']);
    exit;
}

check_csrf();
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$reason = trim((string) ($_POST['reason'] ?? 'Solicitado pelo vendedor'));
if (!$id || mb_strlen($reason) < 5 || mb_strlen($reason) > 180) {
    http_response_code(422);
    echo json_encode(['error' => 'Informe um motivo válido.']);
    exit;
}

$stmt = db()->prepare("SELECT o.*, u.lunarpay_api_key FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = ? AND o.user_id = ?");
$stmt->execute([$id, current_user_id()]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$order || $order['status'] !== 'paid' || empty($order['pix_id'])) {
    http_response_code(404);
    echo json_encode(['error' => 'Venda paga não encontrada.']);
    exit;
}

$result = lunarpay_refund((string) $order['lunarpay_api_key'], (string) $order['pix_id'], $reason);
if ($result['http_code'] < 200 || $result['http_code'] >= 300 || empty($result['data']['success'])) {
    http_response_code(422);
    echo json_encode(['error' => $result['data']['error'] ?? 'Não foi possível solicitar o reembolso.']);
    exit;
}

db()->prepare("UPDATE orders SET status = 'refunded', refunded_at = datetime('now') WHERE id = ? AND user_id = ? AND status = 'paid'")
    ->execute([$id, current_user_id()]);
audit_event(current_user_id(), 'order_refunded', $id, client_ip());
echo json_encode(['success' => true, 'status' => 'refunded']);
