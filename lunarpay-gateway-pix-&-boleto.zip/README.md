# LunarPay Gateway Pix & Boleto — Clone Completo

Sistema completo de gateway de pagamentos multi-usuário com checkout instantâneo Pix, emissão de boletos, cupons de desconto, painel administrativo moderno em React SPA e API REST pública.

---

## 🚀 Acesso Imediato ao Preview

- **Landing Page Pública**: `/`
- **Checkout de Produto (Exemplo)**: `/pagar.php?p=plano-pro` ou `/pagar.php?p=curso-gateway`
- **Checkout de Valor Livre do Lojista**: `/index.php?u=admin`
- **Painel Administrativo SPA**: `/admin/app/` (ou `/admin/login.php`)
- **Configuração Inicial (Setup)**: `/admin/setup.php`

### 🔑 Credenciais Pré-configuradas (Administrador / Dono):
- **Usuário**: `admin`
- **Senha**: `Admin12345678`

---

## ⚡ Funcionalidades do Gateway

1. **Checkout Pix Instantâneo (`pagar.php` & `index.php`)**:
   - Geração de QR Code e código Copia e Cola.
   - Aplicação de cupom de desconto em tempo real com validação no backend (`DESCONTO10` cadastrado com 10% OFF).
   - Verificação em tempo real a cada 3 segundos com atualização visual imediata para status "Pago".
   - **Botão de Simulação Instantânea** (`⚡ Simular Pagamento Aprovado`): Permite demonstrar no vídeo do YouTube o pagamento sendo aprovado e o status mudando para verde sem precisar gastar dinheiro real.

2. **Painel Administrativo React SPA (`admin/app/` e `admin-app/`)**:
   - **Dashboard**: Métricas em tempo real, saldo disponível, faturamento do dia, gráfico semanal e checklist de configuração.
   - **Gerar Pix**: Emissão avulsa com chave temporária e QR Code.
   - **Gerar Boleto**: Emissão de boletos com linha digitável e dados do pagador.
   - **Extrato & Vendas**: Lista paginada com filtros por status (Todos, Pagos, Pendentes, Reembolsados) e ações de estorno.
   - **Produtos**: Cadastro com imagem, título, descrição, estoque e link fixo de checkout.
   - **Cupons**: Criação e gestão de cupons percentuais vinculados à conta.
   - **Saques & Aprovação**: Solicitação de saques Pix com aprovação pelo proprietário.
   - **Usuários & Multi-tenant**: Cada usuário gerencia seus próprios produtos, vendas e chaves.
   - **Taxas & Rotas**: Controle das tarifas nominais aplicadas pela plataforma.
   - **API & Tokens**: Geração de tokens `Bearer gwk_...` e documentação de integração.
   - **Auditoria**: Logs de auditoria com IP, data e evento registrado.

3. **API Pública para Desenvolvedores (`api/`)**:
   - `POST /api/create_charge.php`: Criação de cobranças externas via JSON ou token Bearer.
   - `GET /api/check_status.php?external_id=...`: Consulta do status do pedido para sistemas de checkout e polling.
   - `POST /webhook.php`: Recebimento de callbacks assinados via HMAC-SHA256 da LunarPay.

---

## 📁 Estrutura do Projeto

- `index.php`: Landing page ou checkout público por usuário (`?u=usuario`).
- `pagar.php`: Checkout direto por produto (`?p=slug`).
- `webhook.php`: Webhook para confirmações de pagamento.
- `router.php`: Roteador do servidor PHP para requisições estáticas e fallback SPA.
- `api/`: Endpoints de criação de cobranças e checagem de status.
- `includes/`:
  - `db.php`: Conexão SQLite / PDO, migrações e triggers.
  - `lunarpay.php`: Integração oficial com a LunarPay (produção e simulação).
  - `auth.php`: Sessões seguras, proteção anti-brute-force e CSRF.
  - `landing.php`: Página de apresentação e vitrine institucional.
  - `telegram.php`: Notificações de vendas em tempo real via Telegram Bot.
  - `uploads.php`: Upload seguro de fotos de produtos.
  - `json_api.php`: Helpers padronizados para respostas REST JSON.
- `admin/`:
  - `app/`: Aplicação compilada do Painel SPA (React, Lucide, Tailwind).
  - `api/`: 18 endpoints REST JSON para o painel de controle.
- `admin-app/`: Código-fonte completo em TypeScript, React Router, Tailwind CSS e Vite.
