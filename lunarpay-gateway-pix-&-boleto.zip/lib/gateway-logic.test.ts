import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDiscount,
  validatePixMinimum,
  formatBrl,
  generateExternalId,
  calculateNetBalance,
} from './gateway-logic.ts';

test('calculates coupon discount correctly and rounds to 2 decimal places', () => {
  // R$ 29.90 with 10% coupon = 26.91
  assert.equal(calculateDiscount(29.90, 10), 26.91);
  // R$ 97.00 with 15% coupon = 82.45
  assert.equal(calculateDiscount(97.00, 15), 82.45);
  // Zero discount
  assert.equal(calculateDiscount(50.00, 0), 50.00);
  // 100% discount
  assert.equal(calculateDiscount(100.00, 100), 0.00);
});

test('validates minimum Pix threshold of R$ 5,00', () => {
  assert.equal(validatePixMinimum(5.00).valid, true);
  assert.equal(validatePixMinimum(10.50).valid, true);
  assert.equal(validatePixMinimum(4.99).valid, false);
  assert.equal(validatePixMinimum(1.00).valid, false);
});

test('generates valid external order id format ord_<hex16>', () => {
  const id1 = generateExternalId();
  const id2 = generateExternalId();
  assert.match(id1, /^ord_[a-f0-9]{16}$/);
  assert.match(id2, /^ord_[a-f0-9]{16}$/);
  assert.notEqual(id1, id2);
});

test('calculates gross and net balances from order list with LunarPay nominal fee', () => {
  const orders = [
    { amount: 29.90, status: 'paid' },
    { amount: 97.00, status: 'paid' },
    { amount: 50.00, status: 'pending' },
    { amount: 26.91, status: 'paid' },
  ];
  const summary = calculateNetBalance(orders, 0.99);
  // Gross = 29.90 + 97.00 + 26.91 = 153.81
  assert.equal(summary.gross, 153.81);
  assert.equal(summary.paidCount, 3);
  // Net = 153.81 * (1 - 0.0099) = 152.29
  assert.equal(summary.net, 152.29);
});
