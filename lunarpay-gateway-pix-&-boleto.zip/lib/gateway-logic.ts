/**
 * Funções puras de lógica do gateway para testes de unidade e regras financeiras.
 */

export function calculateDiscount(amount: number, percentOff: number): number {
  if (percentOff <= 0) return Math.round(amount * 100) / 100;
  if (percentOff >= 100) return 0;
  const discounted = amount * (1 - percentOff / 100);
  return Math.round(discounted * 100) / 100;
}

export function validatePixMinimum(amount: number): { valid: boolean; error?: string } {
  if (amount < 5.0) {
    return { valid: false, error: 'Valor mínimo é R$ 5,00.' };
  }
  return { valid: true };
}

export function formatBrl(val: number): string {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
}

export function generateExternalId(): string {
  const chars = '0123456789abcdef';
  let rand = '';
  for (let i = 0; i < 16; i++) {
    rand += chars[Math.floor(Math.random() * chars.length)];
  }
  return `ord_${rand}`;
}

export function calculateNetBalance(orders: Array<{ amount: number; status: string }>, feePercent = 0.99): {
  gross: number;
  net: number;
  paidCount: number;
} {
  const paid = orders.filter((o) => o.status === 'paid');
  const gross = paid.reduce((sum, o) => sum + o.amount, 0);
  const net = Math.round(gross * (1 - feePercent / 100) * 100) / 100;
  return {
    gross: Math.round(gross * 100) / 100,
    net,
    paidCount: paid.length,
  };
}
